# R6-Ic 단독 롤백
1. Unity Play Mode 종료. 동시 작업 파일 변경 여부 확인.
2. ZIP ORIGINALS/Assets/...의 ActionResolver.cs, BattleActionPresentationService.cs, R6IbRealExchangeInsertionVerification20261030.cs 3개를 같은 Assets 경로에 복원.
3. 신규 Assets/1. Scripts/Runtime/Abilities/Reactions/R6StepTraceRecord.cs 와 Assets/1. Scripts/Editor/Verification/R6IcStepPresentationVerification20261030.cs 및 두 .meta 삭제.
4. Unity Refresh/Compile. R6-Ib Actual Mid-Exchange / R6-Ia / R5-W / Golden / Damage G1 회귀 실행.
5. 기존 R6-Ib Stepwise, R6 Frame, R1~R5 패치, 씬 및 에셋을 롤백하지 않는다. GitHub Commit/Push 없음.
