# Project Abyss — R6-Ic 단계별 Presentation + StepTrace 1차 통합 (2026-10-30)

전제: R6-Ia ReactionQueue, R6-Ib ActualStepwise, R1~R5 기존 패치가 적용된 로컬 Project Abyss.

## 수정 (수정 전 사본은 ORIGINALS/Assets 아래 포함)
- Assets/1. Scripts/Runtime/Systems/Resolution/ActionResolver.cs
- Assets/1. Scripts/Runtime/Presentation/Visual/Core/BattleActionPresentationService.cs
- Assets/1. Scripts/Editor/Verification/R6IbRealExchangeInsertionVerification20261030.cs

## 신규 (+ 각 .meta)
- Assets/1. Scripts/Runtime/Abilities/Reactions/R6StepTraceRecord.cs
- Assets/1. Scripts/Editor/Verification/R6IcStepPresentationVerification20261030.cs

## 구현 내용
1. IBattleActionStepPresentation을 기존 IBattleActionPresentation과 별도 optional interface로 추가. 기존 일반 PlayClash 사용자의 인터페이스/기본 동작을 바꾸지 않는다.
2. 실제 BattleActionPresentationService.PlayCommittedExchange()가 "이미 결과 목록에 커밋된" 단 하나의 ClashExchangeResult로 읽기 전용 시각화 slice를 만들고, 기존 BattleVisualRequestBuilder.BuildClashSequence + BattleAnimationDirector.Play로 순서대로 넘긴다. 피해/굴림/상태를 UI에서 재계산하거나 새 이벤트를 발행하지 않는다.
3. ActionResolver.EnableR6StepwiseClashes()는 IBattleActionStepPresentation이 없는 Presenter에서는 실행 거부. 잘못된 Presenter로 전투를 시작해 결과 재생이 어긋나는 것을 방지한다.
4. R6 Stepwise 모드에서는 실제 ClashManager 교환 커밋 -> R6ExchangeSettled -> 해당 교환의 PlayCommittedExchange 완료 -> AfterExchangeSettled 반응 큐 -> 실제 반응의 기존 PlayClash 완료 -> 다음 원본 교환 순으로 진행한다.
5. R6 Stepwise 모드에서 최종 원본 전체 ClashResultContext에 대해 PlayClash를 다시 호출하지 않는다(중복 롤/데미지 UI 방지). Legacy 모드는 기존 전체 PlayClash 그대로 유지.
6. R6StepTraceRecord로 ExchangeCommitted / ExchangeVisualCompleted / ReactionCommitted / ReactionVisualCompleted / OriginalActionCompleted의 단조 증가 sequence, 원본 ActionId, 반응 ActionId/RootActionId/CauseEventId/ExchangeIndex를 기록한다. 이 기록은 게임 로직을 구동하지 않는다.
7. R6-Ib 실제 Play Mode 테스트용 Presenter도 새 인터페이스로 개편해 이전 17개 회귀 유지. R6-Ic 전용 11개 검증 추가.

## 아직 미완료 / 주의
- 실제 BattleAnimationDirector에 에셋이 연결된 상태에서 **시각적 Timeline·카메라·모션·스테이지 연속성 검수는 하지 않았다.** 코드상 각 교환을 별도 단일 교환 시퀀스 요청으로 재생하므로, 매 교환의 입장/종료 연출이 반복될 수 있다. R6-Ic 최종 품질/연속 컷신 Gate는 별도 후속 작업.
- 이번 Play Mode 테스트는 실제 ClashManager HP/교환/반응과 테스트용 fake Presenter의 호출 순서 검증이다. 실제 cutscene Asset, Sound, Camera의 화면 검증 PASS를 주장하지 않는다.
- HifumiMechanic 동기 반격을 신규 Producer로 이관하지 않았으며, 기존 OnClashResolved에서 반격을 호출하는 Legacy 경로를 그대로 유지. 중복 Producer 자동 등록 없음.
- 현 BattleRuntimeFactory 기본 ActionResolver의 R6Stepwise 사용은 여전히 비활성(명시적으로만 Enable), 생산 콘텐츠 전반에 적용된 것이 아니다.
- 기존 SkillDefinition/씬/프리팹/Animation/Timeline/SO는 변경하지 않았다. GitHub commit/push 없음.

## 사용
이미 사용자 로컬 Unity Editor에 변경이 적용됨. 이 ZIP은 독립 전달/롤백용. 고유 최상위 폴더 ProjectAbyss_R6Ic_VisualStepTrace_20261030/의 Assets 경로를 프로젝트 Assets에 병합하면 적용된다.
