# Before / After

Before (R6-Ib opt-in):
3회 실제 교환 중 2회 후 반응이 도메인에서 실행 가능했지만, 원본 PlayClash는 합 종료 시 전체 교환을 다시 재생. 따라서 화면이 원본 0/1/2교환보다 반응을 먼저 표시하거나 중복 표시할 수 있었음.

After (R6-Ic opt-in):
원본 Exchange 0 계산 확정 → 원본 Exchange 0 시각화 완료 →
원본 Exchange 1 계산 확정 → 원본 Exchange 1 시각화 완료 →
반응 Action(독립 ID) 계산 확정 → 반응 Action 시각화 완료 →
원본 Exchange 2 계산 확정 → 원본 Exchange 2 시각화 완료 →
원본 결과 완료(다시 재생 안 함).
기존 레거시 ResolvePair+PlayClash 경로 그대로 유지.
