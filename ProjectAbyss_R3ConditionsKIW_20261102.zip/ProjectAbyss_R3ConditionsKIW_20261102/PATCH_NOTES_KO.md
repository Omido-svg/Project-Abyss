# Project Abyss R3 Condition Patch — 2026-11-02

## Scope
R3 main, R3-K and R3-I contracts only. No automatic existing SkillEffectCondition/ScriptableObject migration, no R4-R7 implementation, no scene save or Git commit.

## Changed source
- AbilityRunner.cs: Existing 6/7 argument Plan APIs preserved. New PlanWithSnapshot binds owner, original, selected, actual damage target and source to immutable facts. PlanCommittedDamage requires settled origin/cause/hit and matching target snapshot. Planned effects are NOT reported as applied.
- DamageResultCondition.cs: AppliedDamageEvidence gains OPTIONAL actual target actor/part fields (original constructor sites stay compatible). Hit provenance and candidate actor/part mismatch are rejected.

## New source
- R3ConditionSnapshotContracts20261102.cs: typed subject, Actor/Part/Slot scope, CharacterContent vs GameplayTag vs SkillTag vs Keyword vs Presence/NumericTotal/EffectiveAxis/Resource facts; copies input facts to prevent later mutation.
- R3ReactionConditionGate20261102.cs: separate request-time trigger/lifetime/result capture from action-start owner/target/part/skill/resource checks. No resource spending or gameplay mutation.
- R3AdvancedConditionVerification20261102.cs: 21 condition/subject/damage gates.
- R3ReactionAndLegacyVerification20261102.cs: 15 PlayMode reaction/legacy checks.

## Limits
Static R3 fact snapshots require a source producer with confirmed live status/keyword/resource values; these new R3 contracts are NOT automatically installed on all skill assets. Example 43/10 mark facts in R3 Edit tests are test fixtures; the separate R2 live Yujin mark query remains intact.
R3-I does not execute a reactive skill, consume resources or solve mid-clash scheduling. R5/R6 must own atomic apply, consume-on behavior and scheduler/UI.
Legacy SkillEffectEntry/Definition target resolution remains unchanged. This patch verifies isolated equality and avoids double registration.
All changes already applied through local Unity MCP; do not reapply ZIP on top of this project state.