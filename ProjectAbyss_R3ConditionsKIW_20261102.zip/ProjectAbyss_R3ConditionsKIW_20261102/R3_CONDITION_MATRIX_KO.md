# R3 K/I condition semantics matrix

| Phase | Source | Target/Identity | Effect |
|---|---|---|---|
| PreTarget | Owner/turn/original cause | Explicit AbilityOwner or SourceActor | Filters before selection |
| CandidateTarget | Selected target slot/part | SelectedTarget actor+part+slot | Filters individual candidates |
| PostDamageResult | Committed receipt | ActualDamageTarget and Cause+OriginHit | Evaluates only after R5 commit |
| ReactionRequest | Settled event and lifetime | Immutable request cause/parent/root/chain | Captures intent; no spending |
| ReactionStart | Current living actor/usable target/part | Actual current actor and cost policy | Cancels invalid drafts; no rollback of prior damage |

All(empty)=true, Any(empty)=false, null tree=true. Legacy condition Invert combined with new Not is an explicit double negation.
Absent actor/part or absent fact is false. StatusPresent, numeric total, effective status axis and per-part keyword stack remain separate typed facts.
Snapshot inputs copy primitive data; mutating producer observation map does not rewrite historic condition observations.
Existing legacy SkillEffectEntry TargetSelector chooses once, then Entry/Definition conditions both see the same target. Invert serialization is unchanged.
R3 uses the R2 and R5 contract boundaries; actual command commit, reaction scheduling and all character-specific storage producers are not auto-enabled in this patch.