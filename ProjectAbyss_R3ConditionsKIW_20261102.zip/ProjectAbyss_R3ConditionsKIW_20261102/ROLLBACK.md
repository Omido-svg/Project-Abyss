# R3 rollback

1. Restore pre-patch AbilityRunner.cs and matching meta from Backups/Before_R3/Assets/1. Scripts/Runtime/Abilities/Runtime.
2. Restore pre-patch DamageResultCondition.cs and matching meta from Backups/Before_R3/Assets/1. Scripts/Runtime/Abilities/Conditions.
3. Remove new R3ConditionSnapshotContracts20261102.cs, R3ReactionConditionGate20261102.cs, R3AdvancedConditionVerification20261102.cs and R3ReactionAndLegacyVerification20261102.cs, together with their metas.
4. Recompile Unity, rerun existing R3, R2, R1 and Damage verification menus.
5. Do not change or save Battle Test Scene, any authored ScriptableObject, or original GUID. No git reset or commit required.