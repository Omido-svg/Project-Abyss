# R3 local Unity verification, 2026-11-02

- Existing R3ConditionVerification20261030, EditMode: PASS 17 FAIL 0.
- R3AdvancedConditionVerification20261102, EditMode: PASS 21 FAIL 0.
- R3ReactionAndLegacyVerification20261102, PlayMode: PASS 15 FAIL 0.
- Total R3: **53 PASS / 0 FAIL**.
- R2 existing contract 7/7, R2 K/W 20/20, R2-I 13/13 and live Yujin Mark 11/11.
- G0 GOLDEN 10/10 and R1 canonical trigger 10/10.
- Damage R1-R7 and G1: 8/8 gates, aggregate 222 PASS / 0 FAIL.
- G0 source SO + meta fingerprint 398 of 398 unchanged, missing 0.
- Unity EditMode restored; Battle Test Scene dirty was not saved. No Git commit/push.

Original machine logs are in Reports/R3_Condition_20261102.