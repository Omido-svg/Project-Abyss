# R3 before and after

| Area | Before | After |
|---|---|---|
| Complex AND/OR/NOT | CombatConditionNode already present | Preserved; nested subject-aware facts tested |
| PreTarget/Candidate | AbilityRunner existing phase split | New immutable context-bound PlanWithSnapshot; old entrypoints unchanged |
| Owner / original / selected / actual / source | Not fully represented in readonly context | R3ConditionSnapshot explicit typed subjects and scopes |
| Status N/T / raw / effective axis / custom stack | Existing enum-driven values | Independent typed fact IDs, no automatic conversion |
| Result provenance | Cause/roll/hit plus additional hit | Optional actual target actor/part; strict committed result gate |
| Reaction checks | R6 request intent and queue existed | Captured origin vs current execution eligibility; actual scheduling unchanged |
| Existing content | G0 398 SOs and meta | 398/398 SHA256 unchanged |