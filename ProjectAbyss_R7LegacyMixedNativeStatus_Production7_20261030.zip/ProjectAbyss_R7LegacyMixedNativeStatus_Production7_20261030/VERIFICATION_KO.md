# Unity MCP test evidence, 2026-10-30

R7 Legacy Mixed Status (Play) PASS=49 FAIL=0
R7 Mixed Native Real Clash (Play) PASS=10 FAIL=0
R7 9 Native Bleeding (Play) PASS=45 FAIL=0
R7 Resource 15 (Play) PASS=53 FAIL=0
G0 (Play) PASS=10 FAIL=0
R1 (Play) PASS=10 FAIL=0
Damage G1 (Play) PASS=46 FAIL=0
R5 Contract (Edit) PASS=15 FAIL=0
R7 Audit (Edit) PASS=10 FAIL=0
R8 Validator (Edit) PASS=10 FAIL=0
TOTAL 258 PASS, 0 FAIL. Some gate checks overlap. Earlier initial mixed test had 6 falsely failing test preconditions, corrected only test harness and clean 49 PASS rerun. R5 intentional exception containment is logged as PASS. Existing scene dirty state preserved.