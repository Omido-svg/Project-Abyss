# Project Abyss R6-Ib — 실제 교환 단계별 전투 실행 (2026-10-30)

## 범위
기존 R6-Ib ClashResolutionFrame / ReactionScheduler AfterExchange 지원에 이어, 실제 ClashManager 교환·피해 계산을 한 교환씩 외부에서 운전하는 opt-in 경로를 구현한다. 기존 ResolvePair() 구현/결과는 DEFAULT로 유지한다. Git commit/push 없음.

## 수정 (원본 ZIP 내부 ORIGINALS 보관)
Assets/1. Scripts/Runtime/Systems/Resolution/ClashManager.cs (partial 키워드 추가만)
Assets/1. Scripts/Runtime/Systems/Resolution/ActionResolver.cs (옵트인 단계별 실행 분기 및 ExchangeSettled 알림)

## 신규 (+ .meta)
Assets/1. Scripts/Runtime/Systems/Resolution/ClashManager.R6Stepwise.cs
Assets/1. Scripts/Editor/Verification/R6IbRealExchangeInsertionVerification20261030.cs

## 실제 구현
- ClashManager.StepwiseSession: Start/Cost/Bind/Duel gate/Prestige, 교환 하나만 커밋하는 Advance, AfterExchangeSettled 이후 Resume, 마지막 정상 Finish/ActionEnd를 보존.
- 기존 ResolvePairedExchange, ResolveOneSideExchange, ApplyExchangeContinuationRules, ApplyExchangeRepeatRules, FinalizeClashSummary, NotifyClashEnded, DamageManager 연결 코드를 그대로 호출. 굴림 수식·피해 공식을 복제하지 않음.
- ActionResolver.EnableR6StepwiseClashes()를 명시적으로 호출할 때만 이 경로 사용; 그 외 기존 Resolver는 ResolvePair 그대로 유지.
- 각 완료된 교환 후 ActionResolver.R6ExchangeSettled 알림(새 Domain Damage event를 재발행하지 않고 완료된 사실만 관찰); 외부 반응 producer는 Queue에 요청만 등록.
- 이어 AfterExchangeSettled queue pump: 기존 ReactionActionRegistry의 독립 ActionId만 호출; 원본 교환 재시도/중복 피해 없이 다음 미소비 굴림 진행.
- 반응이 적을 처치하면 원본 다음 굴림 전 CanContinueRoll 확인으로 중단.
- IDisposable 세션을 통해 예외/Coroutine 취소 시 ActionStart/End 원장 수명 정리.

## 한계 / 다음 작업
- 실제 Unity 3교환→2번째 이후 반응→3번째 교환을 검증했지만, UI는 아직 원본 전체 결과 PlayClash를 합 종료 시 재생한다. 반응 PlayClash가 먼저 재생될 수 있으므로 교환별 UI/Timeline 순서 정합화는 R6-Ic로 분리.
- 실제 캐릭터 반격 히후미 ReactiveRollSequence / 적 반격병 Golden 이관하지 않음. 원본 HifumiMechanic 동기 반격 직접 호출을 유지; 신규 Producer와 동시 활성화 금지.
- 복잡한 동률 재굴림·continuation·보스·명성 등의 모든 조합에서 새 Stepwise와 Legacy의 수치·이벤트 동등성을 보장하는 전수 Golden은 아직 없음.
- 기존 별도 ClashResolutionFrame 계약과 실전 StepwiseSession의 내부 상태 통합은 추가 정리가 필요.
- BattleRuntimeFactory가 일반 전투용 ActionResolver의 Stepwise 모드를 강제로 활성화하지 않으므로 프로덕션 기본 경로는 변경되지 않음.
- Scene/Prefab/ScriptableObject/기존 GUID 파일 수정 없음.
