# Unity MCP 검증 — 2026-10-30

R6-Ib Actual Mid-Exchange Insertion (Play Mode): 17 PASS / 0 FAIL.
- 3번의 실제 paired exchange 진행
- 2번째 교환 완료 이벤트 직후 독립 ReactionAction/ActionId 등록
- 반응을 실제 ClashManager에서 적용하고 3번째 원본 교환 이전 완료 (시점 assert)
- domain trace: main-0, main-1, reaction-requested, reaction-executed, main-2
- HP 예시 player 720→717, enemy 60→36
- 별도 강한 반응 테스트에서 2번째 교환 뒤 원본 타깃 처치(enemy HP 0) → 3번째 원본 굴림 미실행
- 중복 RequestId 거부/원샷 바인딩/Legacy factory 기본 opt-in 금지 확인

그 외 기존 회귀:
Edit: R6-Ib frame 19/0, R6-Ia queue 19/0, R2 7/0, R3 17/0, R4-W 18/0, R4 cache 13/0, R5 command 15/0, R6 memory 16/0.
Play: R6-Ia live 14/0, R5-W live 20/0, G0 Golden 10/0, R1 10/0, Damage G1 46/0.
위 실행 합계 241 PASS / 0 FAIL (일부 테스트가 동일 기능을 중복 검증하는 점 주의).
컴파일 오류 없음, 실제 오류 로그 0건, Play Mode 종료, 기존 dirty Scene 보존.
UI StepTrace/R6-Ic 및 히후미·적 반격병 최종 Golden 미검증.
