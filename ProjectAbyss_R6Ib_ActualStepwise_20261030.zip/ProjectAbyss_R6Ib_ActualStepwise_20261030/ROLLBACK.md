# R6-Ib 실제 Stepwise 패치 단독 롤백
1. Unity Editor Play Mode 종료. 다른 에이전트/사용자의 동시 수정 여부를 확인.
2. ZIP ORIGINALS/Assets/...의 ClashManager.cs 와 ActionResolver.cs를 정확한 원래 Assets 경로에 복원. .meta는 기존 그대로 유지.
3. 신규 ClashManager.R6Stepwise.cs 및 R6IbRealExchangeInsertionVerification20261030.cs 와 각 .meta 삭제.
4. Unity Refresh/Recompile. 이전 R6-Ib Frame Foundation, R6-Ia Queue, R1, G0 Golden, Damage G1 회귀 확인.
5. R6-Ib FrameFoundation 이전 패치 및 R1~R5는 그대로 유지; Scene/Prefabs/SO/Git 상태 건드리지 않음.
