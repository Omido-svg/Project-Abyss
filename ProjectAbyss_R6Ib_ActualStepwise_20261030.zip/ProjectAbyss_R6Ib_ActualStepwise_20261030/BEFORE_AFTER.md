# 변경 전후 실행 경로

BEFORE:
ActionResolver.ResolveClashQueue → ClashManager.ResolvePair(3교환을 동기 일괄 확정) → PlayClash(최종 결과)
반응 큐는 AfterClashCompleted / AfterActionCompleted를 수행. AfterExchangeSettled Queue/Frame 계약은 있지만 실제 한 교환씩 멈추는 호출부가 없었다.

AFTER (명시 EnableR6StepwiseClashes):
ActionResolver → ClashManager.BeginStepwise(pair) → StepwiseSession.Advance(#0) → AfterExchangeSettled Pump → Advance(#1) → ReactionRequest → 전문 ClashManager.ResolvePair(new ClashPair(반응)) → Resume → Advance(#2) → FinalizeClashSummary/남은 일방타격/합종료 → PlayClash(원본 최종 결과).

기본 경로: 여전히 ResolvePair(pair) 완전 동일. 자체 피해/굴림 수식 중복 없음.
주의: 실제 UI는 교환별 단계 재생이 아닌 결과 최종 재생이므로 R6-Ic가 아직 필요.
