# R4-Wa/b — 2026-10-30
실제 추가: Assets/1. Scripts/Runtime/Abilities/Targeting/SlotWeightedTargetPlanner.cs 및 Editor/Verification/R4SlotWeightedPlannerVerification20261030.cs (+각 .meta).
메인 우선 예산 지불, 서브 후보 안정 정렬(피지정 횟수, AreaPriority, SlotOrder, ActorId, SlotId), 마지막 슬롯 부분 배정, HitTargetKey 중복 제거, 잘못된 스냅샷 명시적 거부.
기존 AttackWeightTargetResolver/ClashManager/DamagePipeline/씬/에셋/프리젠터 수정 없음. 이 계약을 라이브 전투/UI에 연결하는 R4-Wc/R5-W/R6-I는 미완료. GitHub 커밋/푸시 없음.