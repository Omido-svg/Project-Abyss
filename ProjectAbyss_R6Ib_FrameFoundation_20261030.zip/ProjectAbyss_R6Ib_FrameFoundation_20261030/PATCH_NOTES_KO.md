# R6-Ib Frame Foundation, 2026-10-30
수정: Assets/1. Scripts/Runtime/Abilities/Reactions/BattleReactionScheduler.cs 및 Assets/1. Scripts/Editor/Verification/R6ReactionSchedulerVerification20261030.cs.
신규(.meta 포함): Assets/1. Scripts/Runtime/Abilities/Reactions/ClashResolutionFrame.cs 및 Assets/1. Scripts/Editor/Verification/R6IbClashFrameContractVerification20261030.cs.
AfterExchangeSettled 체크포인트를 큐에 허용하고 ClashResolutionFrame의 Step, ResumeAfterCheckpoint, 실제 적용 완료된 인덱스, 재개 전 유효성, 중복 커밋·예외 재시도 차단 계약을 도입.
주의: 현 ClashManager.ResolvePair는 아직 동기 전체 처리로 남아 있다. 프레임 계약/모의 커밋 검사만 완료했으며 실제 교환 도중 반응 스킬 삽입과 재개는 미완료. 기존 히후미 동기 반격, Scene, SO, Prefab, DamageManager 공식 무변경. GitHub commit/push 없음.