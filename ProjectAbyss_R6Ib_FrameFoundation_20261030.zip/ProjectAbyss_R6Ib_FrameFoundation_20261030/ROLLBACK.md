1. Unity Play Mode 종료.
2. ZIP ORIGINALS/Assets/... 에서 BattleReactionScheduler.cs, R6ReactionSchedulerVerification20261030.cs 원본 복원.
3. 신규 ClashResolutionFrame.cs 및 R6IbClashFrameContractVerification20261030.cs, 두 .meta 삭제.
4. Unity Refresh/Compile, R6-Ia/R5-W/G0/R1/Damage G1 재검증. 기존 다른 패치 및 씬 수정 상태 보존.