# BEFORE / AFTER — G0 only

|Item|Before|After|
|---|---|---|
|Existing G0 asset audit|Existing G0AbilityAuditReport20261029 outputs|Preserved and regenerated 2026-11-02|
|Golden PlayMode|Previous baseline|10 PASS, 0 FAIL; 7 G0 + 3 legacy weight scenarios|
|I counter parity|Not included in G0 freeze output|Hifumi actual PlayMode parity 24 PASS, 0 FAIL; separate execution trace|
|K decision ledger|Scattered in G0 report|Explicit 6 missing, 10 undecided, observed scope conflicts|
|W authored assets|No verified enabled weighted content|145 SkillDefinitions audited, 0 weight>1, protected paths recorded|
|Assets fingerprints|Existing GUID scan|398 full-asset and .meta SHA256 manifest|
|Combat Runtime|Unchanged|Unchanged|
|Damage/Status event count|G0-G07 Before AfterDamage=1, DamageEvent=3|Same: AfterDamage=1, DamageEvent=3|
|Hifumi damage parity|Legacy baseline|Legacy vs deferred: 7/7 and 13/13 HP damage with matching roll traces|
