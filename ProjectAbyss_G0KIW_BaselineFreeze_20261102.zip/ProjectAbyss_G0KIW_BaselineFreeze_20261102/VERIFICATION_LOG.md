# G0 Verification 2026-11-02

- [PASS] G0AbilityAuditReport20261029.RunAuditFromMenu: PASS=1 FAIL=0 (asset scan).
- [PASS] G0AbilityAuditReport20261029.RunGoldenBaselineFromMenu: PASS=10 FAIL=0 (live PlayMode).
- [PASS] G0KIWBaselineFreeze20261102.Run: PASS=10 FAIL=0 (live EditMode).
- [PASS] R6HifumiDeferredParityVerification20261030.Run: PASS=24 FAIL=0 (live PlayMode). This test is retained as G0-I baseline and does NOT claim R6 production integration.
- [PASS] Scene missing MonoBehaviour scripts: 0 (9 roots).
- [PASS] Duplicate GUID groups: 0; fatal Missing Scripts: 0.
- [PASS] Assets fingerprinted: 398; malformed/meta absent: 0.
- [INFO] Unresolved 6 K identifiers, 10 keyword policies, 20 manual review effect entries. R1-R6 follow-up required.
- [INFO] Scene is currently dirty; no scene save was performed.

See Reports/G0_Ability_Audit_20261029/G0_GOLDEN_BASELINE.json and Reports/G0_KIW_Baseline_20261102/G0_I_HIFUMI_PLAYMODE_PARITY.log for concrete run outcomes.
