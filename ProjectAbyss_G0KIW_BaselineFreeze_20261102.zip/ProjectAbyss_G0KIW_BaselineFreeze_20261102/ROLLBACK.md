# Rollback — G0 only

1. Remove Assets/1. Scripts/Editor/Verification/G0KIWBaselineFreeze20261102.cs and its .meta (new files only).
2. The G0_Ability_Audit_20261029 and G0_KIW_Baseline_20261102 directories are diagnostic reports outside Assets; archive or remove if no longer wanted.
3. No production script/scene/prefab/SO was overwritten, so no gameplay rollback is necessary.
4. Do not overwrite or save the active Battle Test Scene as part of this patch.
