# R5 패치 롤백 안내

1. `Backups/Before_R5/Assets`에서 아래 **수정 전** .cs/.meta를 원래 Assets 상대 경로로 복원한다:
   - 1. Scripts/Runtime/Abilities/Operations/R5CombatCommandContracts.cs
   - 1. Scripts/Runtime/Abilities/Operations/R5CombatSpecialistBackend.cs
2. 아래 **신규** C#과 대응 .meta를 삭제한다:
   - 1. Scripts/Runtime/Abilities/Operations/R5ReactionRequestCommandBackend20261102.cs
   - 1. Scripts/Runtime/Abilities/Operations/R5MultiTargetDamageBatch20261102.cs
   - 1. Scripts/Editor/Verification/R5ReactionCommandVerification20261102.cs
   - 1. Scripts/Editor/Verification/R5MultiTargetDamageVerification20261102.cs
   - 1. Scripts/Editor/Verification/R5MixedDamageReactionVerification20261102.cs
3. Unity AssetDatabase Refresh/컴파일 후 기존 R5 Command Apply, Specialist/Plan/W, R4, Damage Gate를 재실행한다.
4. 원본 SkillDefinition/.meta GUID, 프리팹, Battle Test Scene은 편집하거나 저장하지 않는다. Git reset/commit/push 불필요.
5. 로컬 Unity에는 이미 적용되어 있으므로 R5 ZIP은 중복 설치하지 말고 변경 이력/롤백 용도로 보관한다.