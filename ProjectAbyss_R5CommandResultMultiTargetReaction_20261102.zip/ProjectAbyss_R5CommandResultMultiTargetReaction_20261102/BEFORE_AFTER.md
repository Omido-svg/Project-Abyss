# R5 변경 전후 비교

| 항목 | 패치 전 | 패치 후 |
|---|---|---|
| CombatCommandKind | DealDamage/ApplyStatus/ChangeResource/RequestReactionAction 등 선언됨 | 기존 enum 숫자 유지; RequestReactionAction 실제 예약 백엔드 추가 |
| 명령 접수 | Phase/Priority/Registration 순서, Attempt Ledger | 동일 로직 유지 |
| 피해 결과 | R5 specialist가 Receipt 양만 반환 | CommandId -> 실제 DamageManager DamageContext 조회, 대상별 HP/Part/Stagger/Weaken/Break/Kill |
| 다중 타깃 | R5-W 브리지로 기존 ClashManager 피해; 별도 명령 배치 결과 부족 | opt-in `R5MultiTargetDamageBatchService`가 메인+보조 대상들을 사전 검증해 별도 단일 R5 명령 배치로 결과 기록 |
| 중복 물리 타깃 | 슬롯 가중치 선택 단계에서 Dedup | 새 명령 배치도 Actor+Part 중복을 사전 차단 |
| 피해 후 근거 | Request와 Result 추적 계약 존재 | 실제 committed DamageContext에 요청자가 제공한 RollUse/Hit ID를 붙일 때만 R3 `AppliedDamageEvidence` 생성 |
| 반응 명령 | R5 kind만 정의; 기존 specialist는 미지원 | 검증된 R6 scheduler intent를 `Scheduled`로 기록, 실제 실행은 미주장 |
| 혼합 명령 | 하나의 backend kind 제한 | Composite backend에서 정확히 한 서비스만 kind 소유하도록 강제 |
| 기존 스킬/씬 | G0 398 소스 에셋 해시 기준 | 398/398 동일; 씬 Dirty/미저장 유지 |

기존 두 런타임 파일의 수정 전 소스/.meta는 `Backups/Before_R5`에 포함. 신규 다섯 C# 파일은 원본 자산을 덮어쓰지 않음.