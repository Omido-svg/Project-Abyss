# R5-W/I 명령·결과 계약

## 피해 명령 (W)
1. R4 확정된 메인+보조 물리 대상을 명시적으로 전달하되, R5MultiTargetDamageBatchService는 **실제 DamageManager 실행 경로의 대안**이다. 같은 행동에 기존 ClashManager 루트와 동시에 등록하면 안 된다.
2. 유효성: ActionId/CauseEventId/Ability Owner 일치, 메인 순서 0, 살아있는 대상/유효 Part, Actor+Part 중복 금지, Raw/Requested damage 일치, SourceCharacter/Action 일치. 모든 명령을 사전 검증한 뒤에만 기존 R5 specialist를 통해 적용.
3. 결과는 타깃마다 `CombatCommandReceipt` + 실제 `DamageContext`로 분리. HP/Part/Stagger/Weaken/Break/Kill을 요청한 그대로 재계산하지 말고 반환된 결과에서 읽는다.
4. 과거 피해의 R3 PostDamageResult 증거는 실제 커밋 성공 + 호출자가 공급한 독립 OriginRollUseId/OriginHitId가 모두 있어야 생성. 실패/흡수/중복/원인 누락은 가짜 적용 사건으로 전파하지 않는다.
5. 재진입/UnknownCommit 시 시도된 CommandId는 자동 재적용 금지. Partial batch 뒤 남은 대상은 무조건 성공했다고 주장하지 않는다.

## 반응 명령 (I)
- `CombatCommandKind.RequestReactionAction`은 피해/상태 명령이 아니라 반응 **의도**. 대상 actor=반응 owner, 명령 ActionId=반응 ParentActionId, CauseEventId 일치, RequestId/Chain/Root/SkillDefinitionId 유효.
- 반응 대기열에 허용되면 `CombatCommandOutcome.Scheduled`, `EffectCommitted=false`, `AppliedAmount=0`; `ScheduledCount`에만 +1. 반응 Skill을 아직 실행하지 않으므로 AbilityRuntimeState 성공 카운트 증가 없음.
- Scheduler의 3개 post-commit checkpoint만 허용. `AfterDamageResultCommitted`는 R6 단위 일시중단 지원 전까지 reject.
- 실제 R6 coordinator가 특정 checkpoint에 호출할 때만 dequeue, Skill 생성/재검사/비용 차감/피해/연출 진행.
- 같은 RequestId 또는 CommandId 재예약은 중복으로 차단. `ScheduleAbility`은 자동으로 동의어 처리하지 않는다.
- Composite backend는 Kind당 정확히 하나의 specialist만 허용.

## 향후 연결
- R6 반응 행동 실행/복귀/이벤트·시각효과 스케줄러, R7 실제 능력·고유 키워드 콘텐츠의 원래 어댑터 없는 직접 라우팅.
- 본 R5 테스트는 API와 분리된 실제 DamageManager 결과는 검증했지만, 모든 레거시 SkillDefinition을 새로운 배치 서비스로 바꾸지는 않았다.