# Project Abyss — R5 Command / Result (2026-11-02)

## 범위
R5 핵심 Command·Result 기반 위에 **다중 실제 대상 피해 결과**와 **반응 행동 요청 명령**을 추가. R1~R4/기존 SkillDefinition·prefab·scene·GUID 및 R6 실제 interrupt scheduler 실행은 변경하지 않음.

## 실제 변경
- R5CombatCommandContracts.cs (기존): `CombatCommandOutcome.Scheduled` enum 값을 기존 멤버 뒤에 추가. 실제 실행/피해 커밋과 분리된 `CombatCommandBatchResult.ScheduledCount` 도입. 기존 enum 숫자는 그대로 유지.
- R5CombatSpecialistBackend.cs (기존): 기존 DamageManager가 반환한 `DamageContext`를 각 CommandId별로 읽기 전용 조회 가능하도록 보관. `ClearBindings` 시 해당 인덱스도 정리. 피해 계산기·실제 DamageManager 호출은 기존 그대로.
- R5MultiTargetDamageBatch20261102.cs (신규): 명시적 피해 대상 집합의 메인 1개+보조 N개의 실제 DamageRequest 검증을 **전체 사전 수행**하고 R5 단일 명령 배치에 순서대로 위임. 동일 Actor+Part 중복·오래된 부위·대상 불일치 시 미적용. 실제 적용 HP/부위/흐트러짐 및 부위 파괴/사망 결과를 대상으로 독립 기록. 확정된 타격만 외부 제공 origin IDs로 `AppliedDamageEvidence` 생성 가능. 미확정/원인 미상은 거부.
- R5ReactionRequestCommandBackend20261102.cs (신규): `RequestReactionAction`의 검증된 부모/루트/원인/소유자/RequestId만 R6 `BattleReactionScheduler`에 Queue. `Scheduled`(Applied=false) 반환. 반응 스킬 실행, 자원 지불, Roll/Clash, 피해 커밋 모두 미수행. `R5CompositeCommandBackend`로 실제 Damage와 같은 배치 내 타입별 단일 처리 가능; 복수 백엔드 모호성은 차단.
- Editor 검증 3종 (신규): R5ReactionCommandVerification, R5MultiTargetDamageVerification, R5MixedDamageReactionVerification 20261102.

## 유지 및 주의
- 기존 `CombatCommandApplyService`는 그대로 유지. 안정적인 Phase/Priority/Registration/Sequence 정렬과 중복 명령 방지, 예외 시 UnknownCommit 격리가 적용됨.
- `R5MultiTargetDamageBatchService`는 **명시적으로 호출할 때만** 실행하며 기존 ClashManager의 자동 피해 경로에 이중 등록하지 않는다. 공격 1회에서 기존 ClashManager가 이미 피해를 주고 있는데 추가 호출하면 이중 피해가 되므로, 호출자는 **한 실행 경로만 선택**해야 한다.
- `R5ReactionRequestCommandBackend`는 요청을 R6 대기열에 넣는 수준. 예약된 반응 스킬 실행/프레임 삽입, 소비 타이밍, 취소 후 후처리, UI 이벤트 재생은 R6 단계. `ScheduleAbility`은 이번에도 의도적으로 미지원.
- 실제 히후미/명성/올라프 키워드 콘텐츠 전면 이관 및 R7 능력 자동 라우팅은 포함하지 않는다.
- 기존 에셋과 메타 G0 SHA-256 기준 398/398 동일, 미저장 씬 보존, Git 커밋/푸시 금지.

## 전달
로컬 Unity에 이미 적용됨. ZIP은 원본 백업 및 이력/복구용으로만 사용하고 같은 프로젝트에 중복 설치하지 말 것.