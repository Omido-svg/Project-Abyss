# R5 Unity 검증 (2026-11-02)

## R5 자체 — 94 PASS / 0 FAIL
- 기존 R5CommandApplyVerification (EditMode): PASS=15
- 신규 R5ReactionCommandVerification (EditMode): PASS=13
- 신규 R5MultiTargetDamageVerification (PlayMode): PASS=13
- 신규 R5MixedDamageReactionVerification (PlayMode): PASS=9
- 기존 R5PlanToSpecialistVerification (PlayMode): PASS=12
- 기존 R5SpecialistIntegrationVerification (PlayMode): PASS=12
- 기존 R5SlotWeightedIntegrationVerification (PlayMode): PASS=20

## 라이브 결과
- 메인 1 + 보조 2 대상 총 3개의 실제 `DamageContext`, HP 피해 합계 6(테스트 상황), 원인 ID 및 물리 대상별 레코드 확인.
- 실제 혼합 R5 배치: 적 HP 57 -> 53. 반응은 1건 큐에 `Scheduled`로 들어가고 실제 실행/적용 커밋으로 보고되지 않음. 재실행 시 명령 적용/예약 중복 0.
- 사전 검증 오류(같은 Actor+Part의 중복, 요청과 타깃 ID 불일치) 시 모든 피해 적용 0.

## 회귀
- R4 Live/Preview 16/22, R3 Reaction 15, R2 I/Mark 13/11, G0 Gold 10, R1 10: 모두 PASS 0 FAIL.
- R4 Edit W/Cache/Query/K = 18+13+12+12; R3 Edit 17+21; R2 Edit 7+20; R1 Contracts 15 PASS.
- Damage R1~R7+G1: 8/8 Gate, 222 PASS / 0 FAIL.
- G0 에셋+meta SHA-256: 398 assets, CHANGED=0, MISSING=0.
- Unity Editor EditMode 복귀, Battle Test Scene 미저장 Dirty 상태 보존, Git commit/push 0.

원본 실행 로그는 `Reports/R5_CommandResult_20261102`에 포함.