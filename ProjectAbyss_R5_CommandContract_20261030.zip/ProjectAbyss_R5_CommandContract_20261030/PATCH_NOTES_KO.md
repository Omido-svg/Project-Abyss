# Project Abyss R5-1: Command Plan/Apply/Receipt 계약 (2026-10-30)

신규 파일:
- Assets/1. Scripts/Runtime/Abilities/Operations/R5CombatCommandContracts.cs
- Assets/1. Scripts/Runtime/Abilities/Operations/R5CombatCommandApplyService.cs
- Assets/1. Scripts/Editor/Verification/R5CommandApplyVerification20261030.cs

구현:
1. CombatCommandKind 및 Envelope(Action/Cause/Ability/Target/Phase/Priority/RegistrationOrder/Sequence/RequestedAmount/CommandId).
2. 전문 Backend에 실제 적용 위임, Receipt(Applied/PartiallyApplied/Absorbed/Rejected/Deferred/Failed/UnknownCommit/SkippedDuplicate), 실제 적용 수치 및 EffectCommitted 명시.
3. Phase→Priority→RegistrationOrder→AbilityIdentity→Sequence 안정 정렬.
4. CommandId 1회 호출 보장, 기획만 됐거나 Deferred인 것은 성공으로 커밋 금지.
5. 전문 서비스가 예외를 던지면 UnknownCommit으로 표시하고 해당 원인의 재시도를 차단. 배치 안전 최대 명령 수 제한.
6. AbilityRuntimeState에는 전문 Backend가 실제 상태 변경을 확인했을 때만 성공 커밋.

범위 제한: 이 코드는 아직 실제 BattleEffectResolver/DamageManager/ResourceService에 연결되지 않았으며, 모의 전문 Backend만으로 계약 검증됨. 실제 HP/상태/자원이나 UI를 R5 신형 커맨드가 자동 변경하지 않는다. 기존 데미지 공식을 재구현하지 않았다.

남은 작업: 실제 전문 백엔드 어댑터, DamageContext/Result 원인 및 명령 ID 중복 방지 최종 연결, Keyword/Status/Slot/Reaction 명령별 서비스 분기, R5-W 다대상 DamageBatch/HitResult, 기존 효과 경로 이중실행 방지 및 실전 비교.

GitHub 커밋/푸시 없음.