# R5-1 계약 단독 롤백
Play Mode 종료 후 신규 C# 3개 및 .meta만 제거하고 Unity Refresh/Compile. 기존 G0/R1/R2/R3/R4 파일, 프리팹, 씬, SO는 건드리지 않음.