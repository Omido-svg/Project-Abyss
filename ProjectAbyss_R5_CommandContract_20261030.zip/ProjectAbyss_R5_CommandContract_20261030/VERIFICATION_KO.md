# R5-1 계약 독립 검증
Unity 메뉴: Game System Verification/R5 - Command Apply Contract (Edit Mode)
PASS=15 / FAIL=0
확인 내용: 전문 서비스 1회 호출, 실제 EffectCommitted로만 성공 처리, CommandId 이중 호출 차단, Deferred 미커밋, 안정 명령 정렬, 복수 명령 1회 능력 활성화, 정체/원인/대상 오류 거부, 미지원 전문 Backend 차단, Absorbed 라벨만으로 성공 처리 금지, 예외 UnknownCommit과 이어진 배치 중단, 불명확 원인의 재시도 차단, 과다 배치 사전 거부, 전투 종료 원장 초기화.

주의: 모의 Backend 테스트이지 실제 DamageManager 회귀 게이트의 R5 최종 검증이 아님. 이후 기존 G0 Golden 10/0, R1 10/0, Damage G1 46/0 회귀 통과.