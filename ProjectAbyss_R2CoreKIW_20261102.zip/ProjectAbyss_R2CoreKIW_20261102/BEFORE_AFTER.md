# BEFORE / AFTER — R2

|Area|Before|After|
|---|---|---|
|5-element contracts|AbilityEventContext / AbilityRunner / AbilityInstance already present|Preserved; independent ability plan and applied-only memory verified (7 original + 4 added assertions)|
|Keyword identities|Existing character-specific mechanic storage; no general ownership-query contract|New stable keyword definition/feature set; required original character ContentId resolver; one binding per runtime actor|
|Mark part state|YujinMechanic already stored native part-specific mark|No storage change; new read-only R2 query returns native left 43/right 10, different owner left 7|
|Olaf Bleed attachment|Existing status source-of-truth|New query contract permits granting Olaf and enemy carrier, but does not migrate/create Bleed content|
|Reaction action provenance|ReactionRequest and scheduler existed|New factory creates independent BattleAction/Skill/AbilityInstance and keeps parent/root/chain/cause; no execution performed by factory|
|Reaction checkpoint|R6 scheduler accepts 3 post-commit points|New typed R2 policy rejects unsupported half-committed damage boundary|
|Weight allocation|R4 planner has CombatSlotRef/HitTargetKey|New immutable snapshot key, phase modifiers, target list copy; 3 slot selections vs 2 physical hits verified|
|Legacy adapter|LegacySkillEffectEntryAdapter existed|No production change; isolated parity test 1 old direct apply = 1 compatibility apply, no double subscription|
|SO/meta|398 G0 assets|398/398 SHA256 and .meta same; no GUID edits|

New work limited to 8 new C#/.meta pairs. Existing files were not replaced, so no pre-patch source backup is needed.
