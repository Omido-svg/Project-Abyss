# R2-K / R2-I / R2-W contracts

## R2-K: character-specific identity
KeywordId != CharacterContentId != ActorRuntimeId != StatusApplicationId != AbilityIdentity/CauseId. Descriptor owns the static display/reference/policy IDs but **never** owns runtime N/T, resource, part stack, HP or mutable activation memory.

- Registration: actual actor runtime ID plus authoritative ContentId from the character data source, no repeated binding. Mismatch rejected.
- Query: (GrantingActorRuntimeId, CarrierActorRuntimeId, KeywordId, optional PartId/SlotId) reads current native storage; missing PartId is invalid for Part-carrier keyword.
- Yujin native Mark: owner A: left 43/right 10; owner B: same target left 7. All isolated.
- Olaf bleed can legitimately reside on enemy's part; the granting owner remains Olaf. Non-registered or wrong owner/ID rejected.

## R2-I: reaction lineage
- ReactionRequest remains an intent, no damage command. Factory creates new BattleAction and character-specific Skill runtime, AbilityInstance and independent memory.
- Frame carries new ActionId, parent/root/cause/chain, original RequestId and ActionOrigin.Reaction.
- Default eligible checkpoints: AfterExchangeSettled, AfterClashCompleted, AfterActionCompleted. AfterDamageResultCommitted has no mid-commit execution at R2.
- R6 owns scheduler/coordinator/policy/actual cost and playback. Hifumi reactive rolls must not be implicitly converted into triggered skill actions.

## R2-W: immutable allocation snapshot
- Key = (ActionId, PlanningRevision, TargetingVersion, PolicyId).
- Candidate SlotRef has actor+slot+part+generation; PhysicalHitKey contains actor+part (or actor alone).
- Snapshot copies primitive targetable slots, eligible state, occupation, modifier phases, base budget. Future input list edits cannot modify it.
- Effective weight staged AtPlanning -> AtActionStart -> OnRollUsing; never mutate SkillDefinition SO.
- Existing R4 planner budgets primary first and deduplicates physical hits AFTER selecting slots. R4/R5 handle live targeting/commit.
