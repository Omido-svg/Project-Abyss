# Project Abyss R2 — 5-element architecture + K/I/W contracts

## Scope (2026-11-02)
Only R2. Existing AbilityRunner, AbilityInstance, AbilityRuntimeState, contracts and R7 production code were inspected and preserved. No legacy effect migration, no runtime combat default routing change, no existing SkillDefinition or .meta modification. All 8 Assets scripts are NEW and include their matching newly generated .meta.

## Runtime additions
- R2CharacterFeatureContracts.cs: stable per-character keyword descriptor, owned storage kind/carrier, immutable static feature set, per-actor one-time binding, actual authoritative CharacterContentId check, explicit owner/target/part read-only snapshot source API.
- R2YujinMarkSnapshotSource.cs: read-only link to existing YujinMechanic.GetMark for a given owner and victim part. No new mark stack store.
- R2TriggeredActionFactory.cs: two requests produce separate Combat ActionId/BattleAction/Skill runtime/AbilityInstance; preserve Root/Parent/Chain/Cause, reject forged owner/skill/reused action IDs; honor owner.CreateRuntimeSkillForLoadout and never fake ResourceCostCommitted.
- R2ReactionContractInterfaces.cs: independent-action draft factory contract + post-commit checkpoint policy, reject unsupported AfterDamageResultCommitted until later R5/R6.
- R2AttackWeightSelectionSnapshot.cs: immutable action+planning revision+targeting version+policy snapshot, selected slots separate from physical hit targets, explicit modifier phases, deterministic bridge to existing SlotWeightedTargetPlanner.

## Editor verification
- R2ExtendedContractsVerification20261102.cs (20 PASS)
- R2TriggeredActionParityVerification20261102.cs (13 PASS)
- R2NativeYujinMarkVerification20261102.cs (11 PASS)
- Unmodified existing R2AbilityContractVerification20261030.cs (7 PASS).

## Limitations and next dependencies
- R2-K provides native Yujin mark read-only integration; remaining character keywords need their own existing-storage readers and production feature registration in later steps. Never pretend all K statuses are migrated.
- R2-I creates INDEPENDENT reaction action drafts; it does not automatically schedule/cast reactions, spend energy, commit damage or replay UI. R6 is responsible for those operations.
- R2-W provides a versioned immutable selection contract; it does not automatically switch legacy SO targeting to SlotWeighted, nor complete R4 planning/Undo or R5 damage fanout.
- The 5-element existing runner still uses R5 ApplyService for actual result commits; R2 plan only cannot report applied effects.

No repository commit/push. Battle Test Scene left unsaved; no scene/prefab serialization changed.
