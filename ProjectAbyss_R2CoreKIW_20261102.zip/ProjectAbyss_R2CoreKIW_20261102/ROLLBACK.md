# R2 ROLLBACK — added-only, no existing source overwrite

1. Remove these 8 new scripts AND matching .meta from Assets at their original paths: R2CharacterFeatureContracts.cs; R2YujinMarkSnapshotSource.cs; R2TriggeredActionFactory.cs; R2ReactionContractInterfaces.cs; R2AttackWeightSelectionSnapshot.cs; R2ExtendedContractsVerification20261102.cs; R2TriggeredActionParityVerification20261102.cs; R2NativeYujinMarkVerification20261102.cs.
2. Refresh Unity asset database. Do not touch AbilityContracts.cs, AbilityRunner.cs, AbilityRuntimeState.cs, BattleReactionScheduler.cs, existing character classes, scenes, SkillDefinition assets or any pre-R2 GUID.
3. Reports/R2_KIW_Contract_20261102 is diagnostic output outside Assets and can be archived independently.
4. Run existing R2 Contract Isolation, R1 timing, Damage R1-R7/G1. No Git reset or commit needed.

The ZIP is an archived patch; changes have ALREADY been applied locally by Unity MCP. Do not reapply on top of the same version.
