Unity MCP 실제 검사: Game System Verification/R6 - Lifetime Memory (Edit Mode)
16 PASS / 0 FAIL: 순수 조건 조회, Apply 성공 후 Commit, Turn/Clash/RollUse/Hit ID 분리, 쿨다운 2턴, 확정 피해 누적, 중복 Hit 제외, 원인 ID 미정 피해 거부, 인스턴스별 독립, Battle 경계 Reset.
다음 기존 R5-W 20/0, G0 10/0, R1 10/0, Damage G1 46/0 회귀 정상. 실제 특수 스킬에 자동 적용되는 것이 아님.