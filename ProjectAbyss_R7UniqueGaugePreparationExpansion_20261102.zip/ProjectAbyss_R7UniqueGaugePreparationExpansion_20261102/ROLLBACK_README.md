# Rollback
Restore original five .cs and .meta from Backups/Before_R7/Assets to their matching Assets paths.
Delete newly added 9 .cs and .meta, plus 5 NativeUniqueGauges SO/.meta and 1 NativePreparations SO/.meta.
If the new folders become empty, remove them and their .meta.
Refresh/compile Unity; verify R7 original resource/status/mixed, Preparation Undo, R6 and damage.
Do not save or replace Battle Test Scene or existing SkillDefinitions, Effects, Items or Augments.
No Git commit, push, reset.
