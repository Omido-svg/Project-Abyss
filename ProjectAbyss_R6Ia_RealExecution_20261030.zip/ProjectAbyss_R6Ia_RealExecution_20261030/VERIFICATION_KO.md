# Unity MCP 실제 검증
- R6-Ia Live Reaction Checkpoints (Play Mode): 14 PASS / 0 FAIL.
- 실제 원본→합 종료 반응→행동 종료 반응 결과/연출 순서: 976010→976011→976012.
- 실제 기존 ClashManager 대상 HP: 60→42 (임시 테스트 행동 3개).
- 별도 ActionId, one-shot 등록, 미등록 요청 거부, 비용 위조·원인 변조 거부, BattleRuntimeFactory 연결 확인.
- R6-Ia pure Queue: 19 PASS / 0 FAIL; R6 Lifetime Memory: 16 PASS / 0 FAIL.
- R5 Command Contract: 15 PASS / 0 FAIL.
- G0 Golden: 10 PASS / 0 FAIL; R1: 10 PASS / 0 FAIL; Damage G1: 46 PASS / 0 FAIL.
- 위 실행 묶음 합계 130 PASS / 0 FAIL. 반복 검증이 포함되어 있으며 최종 R6-Ia Gate를 의미하지 않음.
- C# 컴파일 OK, Unity Console 오류 0건, Play Mode 종료.
