1. Unity Play Mode 종료 후 동시 파일 수정 여부 확인.
2. ZIP ORIGINALS/Assets/...의 ActionResolver.cs, BattleRuntimeServices.cs, BattleRuntimeFactory.cs 3개를 원래 Assets 위치로 복원.
3. 신규 R6ReactionActionRegistry.cs, R6ReactionExecutionRecord.cs, R6ReactionActionExecutionVerification20261030.cs 및 각 .meta 삭제.
4. Unity Refresh+Compile; 기존 R6 Queue, R5, G0, R1, Damage G1 검증.
5. 이전 R6 반응 큐/수명/기타 R1~R5 패치와 씬은 유지하고 GitHub 커밋하지 않는다.