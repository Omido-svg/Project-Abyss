# Project Abyss — R6 전용 반격 실제 연결 + R7/R8 전수 Dry Run (2026-10-30)

## 변경 사항
- R6SpecialistReactionRegistry: 일반 ActionSlot 한 번으로 표현할 수 없는 히후미 친치로 연쇄 반격을 원래 메커닉 코드 그대로 지연 실행하는 전용 등록기.
- BattleReactionScheduler: battle-local 고유 RequestId 할당. 현재 메인 큐의 원샷/deterministic 정렬 및 Chain/Depth 안전장치 재사용.
- BattleRuntimeServices/BattleRuntimeFactory: SpecialistReactionRegistry를 battle-local로 생성, ActionResolver에 연결, 재초기화 시 clear.
- ActionResolver: AfterClashCompleted/AfterActionCompleted 등 기존 R6 체크포인트에서 specialist payload를 실행. 기존 ordinary ActionSlot 반응과 명확히 분기하고, 불명확한 specialist 적용 결과의 동일 Chain 반응을 모두 차단.
- HifumiMechanic.TryEnableR6DeferredCounters(): **명시적 Opt-in**일 때만 기존 OnClashResolved·대실패 유래 반격을 AfterClashCompleted로 예약. 실패 시 원래 ResolveCounterSequence 직접 실행으로 fallback. 기본 옵션 OFF. 반격 자체의 RollStandalone, catastrophe, Bone, DamageRequest/Result 원래 공식을 변경하지 않음.
- HifumiMechanic.OnUnregister: opt-in 상태 초기화.
- R7SkillMigrationDryRun: 모든 실제 SkillDefinition 145개 읽기 전용 감사, 중복 SkillId 및 레거시 효과/후보 분류. 프로젝트 루트 CSV/MD 작성.
- R8SkillAuthoringValidation: 모든 스킬의 저작 게이트 검증, 구조적 blocker vs warning 리포트. 에셋 자동 수정 없음.

## 실제 PlayMode 증거
- 실제 Hifumi_Test.prefab 두 개를 초기화한 후 동일 Unity Random state로 기존 counter vs Deferred counter 실행: 대상 HP 피해 **둘 다 7**.
- BattleReactiveRollEvent 완료: 양쪽 **SequenceIndex 0, SequenceCount 1, Power 7, SourceKind Counter** 동일.
- 지연 방식은 체크포인트 이전 피해/반격 이벤트 없음. 체크포인트에 1회 실행하고 중복 재시도 금지.
- 이어 실제 ActionResolver가 별도의 히후미 지연 반격을 소비하는 실행까지 검증.
- Specialist 일반 실전 조정자: 실제 DamageManager HP 변화, 우선순위, 원장, UnknownCommit Chain 전역 차단.
- 이전 R1~R6 및 Damage G1 독립 회귀 검증 모두 통과.

## 주의 / 미완료
- 실제 생산 Hifumi 및 모든 스킬은 DEFAULT LEGACY. TryEnableR6DeferredCounters는 운영 루트에서 자동 호출되지 않음.
- 원본 즉시 반격과 지연 반격의 다른 캐릭터/중첩 상태/골단 만개/대실패 추가 굴림까지의 전체 Golden 동등성은 미확인.
- 실제 Timeline의 멀티교환 연속 카메라/재입장 연출 문제는 R6-Ic 잔여.
- R7 분류의 시범 후보 9개는 데이터/메타데이터 후보일 뿐 실제 AbilityRunner 콘텐츠 이관 완료가 아님.
- R8 현재 게이트는 8개의 중복 SkillId asset blocker 때문에 BLOCKED. 임의 ID 재발급·자동 덮어쓰기 안 함.
- SkillDefinition/Prefab/Scene/Timeline/SO와 GitHub 리모트 변경/커밋/푸시 없음.
- Battle Test Scene의 기존 dirty 상태 미변경.

## 사용
로컬 Unity에 이미 적용 완료. ZIP은 독립 아카이브/롤백/전달 목적. 최상위 폴더 아래 Assets/ 를 기존 Assets/에 병합할 수 있지만 현재 프로젝트에 재적용 불필요.
