# R6 Specialist + R7/R8 DryRun 단독 롤백
1. Unity Play Mode 종료 후, 다른 사용자/에이전트 동시 수정을 확인.
2. ZIP ORIGINALS/Assets/... 아래의 기존 수정 파일 5개를 같은 Assets/... 경로로 복원. Unity의 기존 .meta 유지.
3. 이번 패치의 신규 C# 6개 및 각 .meta만 삭제.
4. Unity AssetDatabase Refresh/Compile, R6-Ia/R6-Ib/R6-Ic/R5-W/G0/R1/Damage G1 검증.
5. 프로젝트 루트 ProjectAbyss_R7_SkillDryRun_20261030.md/.csv 및 ProjectAbyss_R8_SkillValidatorDryRun_20261030.md는 읽기 전용 생성 보고서. 필요시 삭제 가능.
6. 기존 R1~R6 패치 전체나 Scene/Prefab/SO를 되돌리지 않는다. Git commit/push 없음.
