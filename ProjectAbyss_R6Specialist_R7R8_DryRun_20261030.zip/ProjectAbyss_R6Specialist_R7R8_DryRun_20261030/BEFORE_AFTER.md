BEFORE: R6 ReactionActionRegistry는 독립 ActionSlot에 대해서만 실행 가능. 히후미 반격은 OnClashResolved 내부에서 별도의 RollStandalone/DamageManager 연쇄 시퀀스로 즉시 실행. 새로운 AbilityRunner/Scheduler는 이를 일반 Skill 1회로 잘못 이관하면 대실패·뼈 보상을 잃을 수 있었음.
AFTER: 별도 R6SpecialistReactionRegistry가 원래 히후미 반격 루틴을 임의로 복제하지 않고 동일 원인/등록기로 지연 호출 가능. 반격은 기존 즉시 실행을 DEFAULT 유지하며, Opt-in 테스트에서 HP 피해·완료 반격 이벤트·순서 동등성과 ActionResolver 소비 확인.
R7/R8 전수 DryRun과 차단 사유 보고서를 생성, 콘텐츠 145개를 실제 변경하지 않음.
