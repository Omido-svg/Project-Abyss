# R7/R8 구조 장애 요약
실측 SkillDefinition: 145개
ActionType: Duel 57 / NormalAttack 37 / Prestige 18 / Preparation 33
Authored EffectEntries: 102개
Legacy Effect references 포함 SkillDefinitions: 11개
Effect 없는 NormalAttack 단순 메타데이터 후보: 9개 (실제 게임플레이 이관 완료 아님)
중복 SkillId: 4종 / 실제 8개 에셋 영향
- olaf.preparation.bloto (2)
- olaf.duel.standard (2)
- yujin.preparation.hwanhyeong.attack (2)
- yujin.preparation.hwanhyeong.defense (2)
R8 저작 Validator: blocker 8 / warning 85. 현재 전체 이관 자동 승인 불가.
자세한 경로/해당 GUID는 AUDIT_REPORTS 내 R7 CSV/MD, R8 MD 참조.
스킬 ID/GUID를 임의 재발급하지 않고 저장 호환·기획 승인 이후 보정 필요.
