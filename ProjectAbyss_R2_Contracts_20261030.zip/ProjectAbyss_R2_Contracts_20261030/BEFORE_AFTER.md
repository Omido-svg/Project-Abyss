# R2 계약 전후
이전: SkillEffectEntry + SkillEffectDispatcher가 런타임 효과의 직접 실행 단위였다.
현재: 기존 실전 실행 흐름은 100% 그대로이며, 별도 ProjectAbyss.Abilities 네임스페이스에 Definition/Instance/Snapshot/Target/Operation/Memory 계약을 추가했다.
중복 호출 방지: LegacySkillEffectEntryAdapter를 기존 Dispatcher와 동시 자동 실행하지 않는다.
R5/R6 이전에는 Command가 실제 데미지/상태를 적용하거나 반응 스킬을 실행하지 않는다.
슬롯 예산은 아직 opt-in이 아니라 데이터 계약만 존재한다. 기존 AttackWeightSettings 및 Resolver 동작은 변경하지 않았다.
