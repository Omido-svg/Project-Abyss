# Project Abyss — R2 5요소 공통 계약 1차 패치 (2026-10-30)
이 단계는 R2의 '계약 도입'만 수행한 초기 패치이며 R2 전체 완료가 아니다.

## 신규 경로
Assets/1. Scripts/Runtime/Abilities/Contracts/AbilityContracts.cs
Assets/1. Scripts/Runtime/Abilities/Runtime/AbilityRuntimeState.cs
Assets/1. Scripts/Runtime/Abilities/Runtime/AbilityRunner.cs
Assets/1. Scripts/Runtime/Abilities/Adapters/LegacySkillEffectEntryAdapter.cs
Assets/1. Scripts/Runtime/Abilities/Targeting/SlotWeightContracts.cs
Assets/1. Scripts/Runtime/Abilities/Reactions/ReactionContracts.cs
Assets/1. Scripts/Editor/Verification/R2AbilityContractVerification20261030.cs

## 분리한 계약
- AbilityEventKind: 실제 굴림 사용/교환/결투 종료 등 내부 사건
- AbilityIdentity/ActorRuntimeId: 같은 Definition을 사용하는 개체 및 슬롯/Entry 분리
- ReadOnly event snapshot / 조건 / 대상 / Operation / CommandSink 인터페이스
- AbilityRuntimeState: 실제 Apply 성공시에만 발동 기억 Commit, Battle 경계 Reset
- AbilityRunner.Plan: 상태를 절대 수정하지 않는 사전 명령 계획. R5 전까지 실제 Apply는 연결하지 않음
- LegacySkillEffectEntryAdapter: 기존 Entry.TryApply를 재사용하는 호환 어댑터(이중 등록 금지)
- R2-W: CombatSlotRef/HitTargetKey/SelectedSlotAllocation을 분리; 기존 가중치 런타임 미변경
- R2-I: ReactionRequest의 원인/부모/루트와 체크포인트 정의; 실행 스케줄러는 R6에서만 추가

## 남은 R2 필수 항목
- 현 실제 Skill/Passive/Emotion/Item 실행 경로를 공통 Runner로 점진 위임
- 새 Rule과 기존 Entry 신구 결과 동등성 테스트
- KeywordId/ActorRuntimeId/StatusApplicationId 등 실제 전문 원장 연동(R2-K)
- BattleActionFactory/ReactionScheduler, SlotWeight 본격 실제 실행은 후속 단계
- R2 컴파일 및 계약 독립 테스트 외 실전 전투 통합 PASS는 아직 아님

## 주의
- 기존 ScriptableObject 직렬화/스킬/피해/프리팹 변경 없음
- R2 계약만으로 새 능력 시스템이 완성되거나 새 공격 가중치가 적용된다고 주장하지 않음
- GitHub 커밋/푸시 없음.
