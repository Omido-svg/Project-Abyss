# R2 계약 검사
Unity 메뉴: Game System Verification/R2 - Contract Isolation (Edit Mode)

실측: PASS=7 FAIL=0
- 서로 다른 ActorRuntimeId는 서로 다른 AbilityIdentity
- 동일 Definition 공유 인스턴스 간 활성화 기억 독립
- 실제 적용 0인 계획만으로는 발동 성공을 Commit하지 않음
- Battle 수명 경계에서 메모리 Reset
- 서로 다른 SlotRef가 같은 HitTargetKey를 가질 수 있음
- SelectedSlot 2개 / DistinctHitTarget 1개가 독립 표현됨
- 반응 요청 ID 2개가 서로 다르면서 Parent/Root/Chain은 보존됨

이 테스트는 pure-contract 검증이며 실제 Unity 전투에 R2 Runner가 연결됐다는 뜻은 아님.
