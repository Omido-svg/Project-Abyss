# R2 계약 패치 롤백
Play Mode 종료 후 신규 파일 7개와 해당 .meta만 삭제한다.
Runtime/Abilities 아래의 기존 파일이 없는 새 경로만 제거할 것.
AssetDatabase Refresh 및 재컴파일 후 기존 전투 테스트 재실행.
R1 패치 파일과 G0 검증 스크립트는 건드리지 않는다.
