# Project Abyss R7 Effectful Bulk Opt-in Bridge + R8 68 Asset Safeguard (2026-10-30)

## 범위/결정
이번 패치는 기존 R7 no-effect 파일럿 이후 **실제 효과가 있는 스킬들을 단일 배치 전환 경로로 다루기 시작하는 중간 단계**다. 기존 SkillDefinition .asset, .meta, Scene/Prefab/Timeline 및 Git 저장소는 수정하지 않았다.

## 코드 변경
MODIFIED (ORIGINALS/Assets 아래 원본 포함)
- Assets/1. Scripts/Runtime/Skills/Base/SkillEffectDispatcher.cs

NEW (+ 각각 .meta)
- Assets/1. Scripts/Runtime/Abilities/Runtime/R7ExclusiveEntryMigrationScope.cs
- Assets/1. Scripts/Editor/Verification/R7EffectfulBatchVerification20261030.cs
- Assets/1. Scripts/Editor/Verification/R7EffectfulMultiAssetParity20261030.cs
- Assets/1. Scripts/Editor/Verification/R8EffectfulBatchPreflight20261030.cs

## 구현 및 실제 확인
- SkillEffectDispatcher.Execute()에서, **명시적 R7ExclusiveEntryMigrationScope가 활성이고 해당 SkillDefinition이 후보인 경우에만**, 기존 ExecuteEntries 대신 새로운 배치 실행 경로를 *독점적*으로 선택한다. Default null → 종전 경로 유지. Owner/global owner effect execution은 기존 방식을 유지.
- 새로운 경로: 실제 SkillEffectContext·Entry별 AbilityIdentity/AbilityInstance 연결 → AbilityRunner.Plan(읽기 전용 명령 인텐트 1건) → 기존 LegacySkillEffectEntryAdapter를 통해 전문 효과 한 번만 실행 → SkillEffectResult.WasApplied에 한해서 결과 원장 Commit. 기존 TryApply가 Timing/Condition/Target/DamageModifier 판정을 계속 담당한다.
- 같은 Entry를 기존 디스패처와 신규 브리지 양쪽에서 동시에 호출하지 않는다. 새 브리지는 복제된 DamageManager, RNG, StatusService를 만들지 않는다.
- 기존 SkillDefinition 145개 중 **중복 ID/레거시 효과 혼용/빈 Entry를 제외한 68개 실제 스킬, 루트 효과 85개**가 이 Opt-in Scope 후보. 지원 목록의 개별 실제 콘텐츠 골든 완료를 뜻하지 않음.
- 실제 PlayMode: yujin.normal.ledger_cleanup에서 레거시/브리지 HP 피해 12/12, OnExecute 전문 효과 Applied 1회. 세 카드 묶음에서는 yujin.normal.ledger_cleanup, yujin.normal.step_back, yujin.normal.familiar_hand의 전후 HP/교환 수와 실제 Applied=1 및 GUID 추적 확인 (19 PASS).
- R8 배치 툴은 후보 68개 각 .asset/.meta 총 **136개** 원본을 정확한 SHA256으로 검증해 Assets 외부 전용 디렉터리에 보관, Effect Entry별 명세(EFF... CSV, 85개 행)를 만듦. 중복 ID는 제외, 원본 바뀐 경우 기존 백업 덮어쓰기 거부.

## 남은 핵심 작업 (절대 완료로 취급 금지)
- **68개는 마이그레이션 Opt-in 후보**이며, 그 중 개별 효과 적용을 실제 비교한 건 세 카드. 프로덕션 BattleRuntimeFactory가 자동 활성화하지 않음. 이 숫자를 “68개 실제 스킬 이관 완료”로 표현하지 말 것.
- 새로운 R7 경로의 실제 Apply는 아직 구 전문 SkillEffectEntryAdapter 기반. 효과/상태/자원 CommandNative 완전 대체, R7 독립 IEffectOperation 및 모든 조건·대상·원인 Command 통합 **미완료**. 현재 AbilityRunner Plan은 실전 커맨드를 직접 적용하는 게 아니라 전문 효과 1회 호출을 준비하는 단일 인텐트임.
- Roll별 EffectEntries, MultiRollPenalty, owner/global effects는 이번 SkillEffectDispatcher root Entry 브리지 범위 밖이며, 기존 전문 실행기에서 처리.
- R8 전체 저작/승인 마이그레이션은 중복 SkillId 4종/8 asset blocker로 여전히 BLOCKED. 임의 ID 재발급 안 함.
- R6 실제 히후미 고난도/반격병 전수 Golden, Timeline 연속 모션 QA, R9/G-FINAL 미완.
- Play Mode 스코프는 IDisposable 사용 필수; 사용자 Production에 Default 켜지 않음.

## 적용
사용자의 로컬 Unity 프로젝트에는 이미 수정 반영됨. ZIP은 독립 전달·롤백 목적. 고유 최상위 폴더 내 Assets 경로를 프로젝트 Assets에 병합. R8_EFFECTFUL_BACKUPS 하위 에셋 원본은 원상복구용 **보관 자료**이며 실제 적용 대상이 아님.
Git commit/push 없음. Scene/Prefab/SO 수정 없음.
