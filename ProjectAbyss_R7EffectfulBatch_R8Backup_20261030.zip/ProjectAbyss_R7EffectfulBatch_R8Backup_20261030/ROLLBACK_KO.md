# 이 배치만 단독 롤백
1. Unity Play Mode 종료, 동시 수정 확인.
2. ZIP ORIGINALS/Assets/1. Scripts/Runtime/Skills/Base/SkillEffectDispatcher.cs → 동일 Assets 경로 원본 복원 (.meta 유지).
3. NEW C# 파일 4개와 각각 .meta 파일만 삭제.
4. Unity Refresh/Recompile, G0/R1/R7/R8/Damage G1 회귀 검사.
5. R8_EFFECTFUL_BACKUPS/ORIGINALS 안의 136 원본 파일은 보존용. 잘못하여 현재 Assets로 전부 복사하지 말 것. 개별 승인된 향후 SO 이관의 문제가 발생한 경우에만 관련 스킬 .asset/.meta를 정확히 식별하고 해시 검증 후 복원.
6. 이전 R1~R7 파일럿, Scene, Prefab, Timeline 및 Git 저장소 상태는 유지.
