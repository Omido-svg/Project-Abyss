# R5 실제 전문 어댑터 단계 단독 롤백
1. Unity Play Mode 종료. 다른 개발자의 동시 수정을 확인한 뒤에만 파일 덮어쓰기.
2. ORIGINALS/Assets/... 3개 파일을 기존 Assets/의 같은 위치에 복원 (AbilityRuntimeState.cs, AbilityRunner.cs, R5CombatCommandApplyService.cs)
3. 이번 ZIP의 신규 소스 4개 및 각 .meta를 Unity Assets에서 삭제한다.
4. AssetDatabase Refresh/Compile. R2/R3/R5Fake/G0/R1/DamageG1 회귀 실행.
5. 기존 R1/R2/R3/R4-W/R4-Wc/R5CommandContract 코드는 유지. 씬 파일을 저장/되돌리지 않는다.
