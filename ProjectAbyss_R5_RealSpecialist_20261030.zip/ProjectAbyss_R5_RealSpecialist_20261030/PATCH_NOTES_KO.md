# Project Abyss — R5 실제 전문 서비스 어댑터 + Plan/Apply 통합 (2026-10-30)
기준: 이전 R1/R2/R3/R4-W/R4-Wc/R5-CommandContract 패치가 설치된 로컬 Project Abyss.
이번 ZIP은 R5 중간 단계(전문 서비스 opt-in 실행, 새로운 엔드투엔드 최소 경로)이며 전체 R5/R1~R9 완료가 아니다.

## 신규 파일
Assets/1. Scripts/Runtime/Abilities/Operations/R5CombatSpecialistBackend.cs
Assets/1. Scripts/Runtime/Abilities/Operations/R5PlannedCommandBridge.cs
Assets/1. Scripts/Editor/Verification/R5SpecialistIntegrationVerification20261030.cs
Assets/1. Scripts/Editor/Verification/R5PlanToSpecialistVerification20261030.cs
(각 .meta 포함)

## 기존 파일 수정
Assets/1. Scripts/Runtime/Abilities/Runtime/AbilityRuntimeState.cs
Assets/1. Scripts/Runtime/Abilities/Runtime/AbilityRunner.cs
Assets/1. Scripts/Runtime/Abilities/Operations/R5CombatCommandApplyService.cs

## 실제 연결
- DamageRequest -> BattleContext.ResolveDamageManager().ApplyDamageContext() -> DamageContext/Result 기반 정확한 AppliedDamage/GuardAbsorbed 판정
- EffectRequest -> BattleEffectResolver.ApplyCharacterStatus / ApplyBodyPartStatus -> StatusEffectApplyResult 기반 성공 여부
- Custom Resource delta -> SkillResourceAccess.Get/Modify -> 실제 Before/After 차이로 적용 수치 기록
- AbilityRunner.Plan -> R5PlannedCommandBridge.Materialize -> 명시적 payload Bind -> CombatCommandApplyService.Apply -> specialist Receipt -> AbilityRuntimeState.Commit
- ActionId/RollUseIndex/이벤트 종류가 같아도 서로 다른 CauseEventId가 독립적으로 처리되도록 ActivationKey 확장 (기존 3-인자 생성 호출 호환)
- Backend가 UnknownCommit을 반환하거나 예외를 던진 경우 이후 명령 진행 중지 및 해당 활성화 원인 자동 재시도 금지

## 안전성 및 미완료
- 이 어댑터는 **자동 등록되지 않음**. 레거시 SkillEffectDispatcher와 동시에 동일 카드에 실행하지 않는다.
- ScriptableObject의 피해/상태 효과 전체를 신형 Command로 자동 이관하지 않았고, 일반 전투는 여전히 Legacy 경로를 사용한다.
- 소스와 타깃은 Register*에서 명시적으로 결합하며, 임의의 string intent만으로 실제 적용되지 않는다.
- ActorRuntimeId는 현재 R4LiveSlotQuery의 Unity InstanceID 기반 battle-local 식별자로, 영속 ID가 아니다.
- Resource/Status 적중 결과를 더 정교하게 구조화하는 DTO 및 공격 가중치 DamageBatch, 후속 이벤트·UI 투사·반응 스케줄러·풀 콘텐츠 이관은 미완료.
- Command payload 등록은 실행 범위 외부에서 임의로 변경하지 말아야 한다. 전투 수명 동안 어댑터와 ApplyService가 함께 관리되어야 한다.
- 별도 NativeICombatCommandBackend를 통해 전문 적용만 실행; 새로운 데미지 공식을 도입하지 않음.
- 실제 Play Mode 검증은 테스트 런타임 캐릭터만 변경했고 Play Mode 종료 후 씬 저장 안 함.
- GitHub 커밋/푸시 없음.

## 적용/롤백
고유 폴더 ProjectAbyss_R5_RealSpecialist_20261030/Assets 아래 상대 경로를 프로젝트 Assets에 병합. 로컬 Unity는 이미 적용되어 있으므로 중복 복사 불필요.
원본 파일은 ORIGINALS/Assets 이하에 별도로 저장하였고 ROLLBACK.md를 참고.
