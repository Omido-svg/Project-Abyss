# Unity MCP actual validation 2026-10-30
R5 specialist Play Mode: 12 PASS / 0 FAIL (actual resource 3->5, character/part status applied, DamageManager HP 60->59, duplicate/rejected cases)
R5 Plan->Real Specialist Play Mode: 12 PASS / 0 FAIL (plan, typed command, cause IDs, commit only on applied, unknown-commit quarantine)
G0 Golden: 10/0; R1: 10/0; Damage G1: 46/0; R2: 7/0; R3: 17/0; R4-W: 18/0; R4-Live: 16/0; R4-Cache: 13/0; R5 fake backend: 15/0.
Arithmetic combined: 176 PASS / 0 FAIL across these test executions (includes overlapping regression areas, not 176 independent gameplay requirements).
Unity Console errors 0; Play Mode stopped; C# compiling false. Existing gameplay remains on legacy path. R5 final gate NOT complete.
