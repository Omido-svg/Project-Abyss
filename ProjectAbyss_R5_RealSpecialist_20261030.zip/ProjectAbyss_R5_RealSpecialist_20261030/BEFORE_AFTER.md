# Before/After
BEFORE: R5CommandContract는 FakeSpecialist 독립검증만 가능했음. 성공 커밋/커맨드 정렬/중복 원장은 있으나 실제 DamageManager/Resource/Status에 연결된 어댑터와 AbilityRunner 계획을 명령으로 바꾸는 경로가 없었음.
AFTER: 실제 Unity BattleContext의 DamageManager, BattleEffectResolver, SkillResourceAccess에 명시적 typed request payload를 바인딩. 독립 AbilityRunner.Plan -> Materialize -> RegisterResourceChange -> Apply -> Receipt -> AbilityRuntimeState 성공 기록 테스트 통과. 기존 행동 Resolve/SkillEffectDispatcher는 변경하지 않아 기존 게임 로직과 자동 이중 실행이 발생하지 않음.
기존 ActivationKey의 3-인자 생성자는 그대로 사용 가능. 이제 CauseEventId가 추가로 매칭에 포함되어 DamageSettled 등 독립 원인에 대한 발동 기억 교차를 방지.
기존 UnknownCommit catch-only 중단에 더해 backend의 직접 UnknownCommit 반환 시에도 배치 종료.
