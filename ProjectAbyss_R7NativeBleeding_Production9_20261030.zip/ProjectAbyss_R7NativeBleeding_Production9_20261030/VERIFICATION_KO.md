# Actual Unity Editor tests 2026-10-30

R7 9 Native Bleeding Status Parity: 45 PASS / 0 FAIL
R7 Native Bleeding Part and Replay: 8 PASS / 0 FAIL
R7 15 Native Production Skill Migration: 53 PASS / 0 FAIL
G0 Golden Baseline: 10 PASS / 0 FAIL
R1 Canonical Trigger: 10 PASS / 0 FAIL
Damage G1: 46 PASS / 0 FAIL
R5 Command Apply Contract: 15 PASS / 0 FAIL
R7 All Skill Migration Readiness: 10 PASS / 0 FAIL
R8 Skill Authoring Validator: 10 PASS / 0 FAIL
TOTAL menu case count: 207 PASS / 0 FAIL. Some features are covered by multiple checks. R5 intentional exception containment logs a PASS diagnostic, not a test failure. Current scene dirty state was preserved, final Play Mode stopped, compiling false.