# R1 ROLLBACK — NO SCENE SAVE

1. In Backups/Before_R1/Assets restore these three original scripts to Assets at the same relative paths, preserving their original .meta: Skill.cs; SkillEffectTiming.cs; ClashManager.cs.
2. Remove new R1CanonicalEventPolicy.cs and .meta and the three newly-added Editor verification scripts and their .meta.
3. Do not alter/replace any character SkillDefinition asset, scene, prefab or GUID. No persistent gameplay data was migrated.
4. Refresh Unity, compile, run existing G0/R1 Golden and damage R1~R7/G1 to confirm original behavior.

The original source backups contain pre-R1 script content and .meta; no Git reset/commit is required.
