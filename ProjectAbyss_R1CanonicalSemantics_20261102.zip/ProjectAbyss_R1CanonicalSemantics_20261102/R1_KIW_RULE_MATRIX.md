# R1-K/I/W Rules Matrix (2026-11-02)

## Core six card authoring triggers

|Card Event|Scope|Frequency|Order/Condition|
|---|---|---|---|
|AttackResolutionStarting|Individual attack card|Once before first actual roll|Not global battle start|
|OnExecute / RollUsing|Actual consumed roll|Once per used roll|Before RNG; never on tie reroll again|
|OnExchangeWin|Paired exchange only|Once per won pair|No unilateral or secondary target win|
|OnExchangeLose|Paired exchange only|Once per lost pair|Before committed damage|
|OnClashEnd|Clash pair|Once, including after remaining unilateral rolls|Never for purely unilateral attack|
|OnPreparationActivated|Preparation action|Once|No synthetic roll/win/loss; OnExecute legacy compatibility preserved|

OnDuelMatched=31 is legacy serialization compatibility only and must never be exposed as a new card authoring trigger. All canonical card effects for Duel require original Duel-vs-Duel eligibility.

## R1-I reaction checkpoint classification

|Checkpoint|Commit boundary|Card trigger?|Scheduler state in this patch|
|---|---|---|---|
|AfterExchangeSettled|Exchange damage/event result committed|No|Available, not automatically enabling R6 stepwise|
|AfterClashCompleted|Complete clash and tail resolved|No|Available for explicit scheduler opt-in|
|AfterActionCompleted|Standalone or action end|No|Available for explicit scheduler opt-in|
|AfterDamageResultCommitted|Individual damage result committed|No|Declared but currently rejected by BattleReactionScheduler until later R5/R6 work|

Hifumi counter-after-clash, Hifumi special failure roll, enemy after-action counter, SecondaryHit, FollowUpRoll, TriggeredSkillAction are not interchangeable. R1-I names semantic boundaries, not new reaction execution behavior.

## R1-W slot-weight rule

AttackWeightBudget >=1. Select main target's slot first and consume min(remaining, SlotWeightCost). Then select secondary slots by stable ranking; partially funded final slot is allowed and still hits once. Deduplicate actual physical hits only AFTER slot budgeting: boss different parts separate, normal enemy identical actor one hit. Only primary is opposed; secondary hits cannot produce independent ExchangeWon/ExchangeLost/ClashEnd. Taunt/Stealth candidate eligibility precedes slot budgeting. Dead target not silently reselected; broken part follows existing HP-only rule.

R1-W is a semantics contract: NO existing SkillDefinition is auto switched from LegacyCharacterRandom to SlotWeighted.

## Roadmap R1-T-TR coverage

|Id|Concrete verified scenario|
|---|---|
|TR01|G0-G01 3-roll paired OnExecute=3 and OnClashEnd=1; L05 attack start once|
|TR02|R1-TieCancel target fatal after first exchange => use once, remaining cancelled|
|TR03|R1-TieCancel five true tie rerolls => one use, final win/loss once|
|TR04|G0-G03 dual Duel full effects allowed|
|TR05|G0-G04 Duel vs normal gate effect zero, normal attack effective|
|TR06|R1-Live L03 lone Duel: card effects zero|
|TR07|R1-Live L02 5-roll vs 1-roll Duel: use 5, exchange win 1, clash end 1|
|TR08|R1-Live L04 3-roll standalone NormalAttack: use 3, exchange win 0|
|TR09|R1-TieCancel 2 wins/1 loss + leftover one-sided: win 2, loss 1, tail 1, clash end 1|
|TR10|G0-G07 AfterDamage 1, actual DamageEvent 3 (two extra hits)|
|TR11|R1-Live L05/L06 global BattleStarted 1, card attack start 2 across actions|
|TR12|R1-Live L07 PreparationActivated 1, exchange win 0|
