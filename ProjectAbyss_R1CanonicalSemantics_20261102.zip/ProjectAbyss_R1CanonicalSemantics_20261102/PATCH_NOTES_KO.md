# Project Abyss R1 Trigger/Clash Rule Patch (2026-11-02)

## Scope
G0 -> R1 only; no R2~R7 content migrations. Run-time behavior changed only at canonical exchange win/loss eligibility guard. Original serialized enum numbers, SO GUIDs, metadata, all scenes are preserved.

## Code
- Added Assets/1. Scripts/Runtime/Abilities/Contracts/R1CanonicalEventPolicy.cs: central R1 1029 factual exchange outcome guard; exact 5+1 card triggers and post-commit checkpoint classification.
- Edited Skill.cs: canonical OnExchangeWin/OnExchangeLose requires isClash, opponent, no one-sided, and frozen Duel-vs-Duel gate when relevant. Legacy serialized phases preserved (not silently migrated).
- Edited SkillEffectTiming.cs and ClashManager.cs: clarify old OnDuelMatched as serialized-only legacy compatibility; no enum numbering or runtime scheduling modified.
- Added 3 Editor verification files: R1CanonicalContractsVerification20261102.cs, R1ExtendedLiveTimingVerification20261102.cs, R1TieAndCancellationVerification20261102.cs.

## Out-of-scope
- Reaction scheduler execution/interruption and UI playback integration are R6. R1-I defines only post-commit checkpoint semantics.
- Slot-weight selection and damage execution are R4/R5; R1-W defines opt-in policy and tests existing pure allocator.
- No SkillDefinition data conversion, no PASS claims for R7 content.

## Safety
No Git commit/push; no scene save; no asset or GUID modification. Existing content and legacy OnDuelMatched compatibility retained.
