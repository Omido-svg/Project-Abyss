# R1 BEFORE / AFTER

|Case|Before|After|
|---|---|
|Canonical exchange win/loss guard|!isOneSided and for Duel opponent type Duel|Require isClash and actual opponent and !isOneSided; Duel additionally requires DuelEffectsEligible and Duel opponent|
|Real paired clash|Eligible|Eligible; original outcome preserved (PlayMode 10+ live test PASS)|
|Unilateral attack|No canonical win/loss|No canonical win/loss, also enforced by shared policy|
|Non-clash caller incorrectly labelled opposed|Could publish canonical outcome|Rejected at R1 policy|
|Duel vs normal|Duel effects gated|Duel effects gated|
|Global OnBattleStarted vs card starting|Separate|Separate, verified by live probes|
|5 tie rerolls|One RollUse intended|One RollUse, proven 5 rerolls + single win/loss|
|Premature death|Remaining rolls cancelled|Verified 1/3 actual uses only|
|Majority 2:1 and last one-sided|Real exchange wins/losses only|2 win +1 loss +1 one-sided +1 clash completed, verified|
|Slot allocation|Opt-in; legacy SO default|Unchanged; pure budget/dedup contract verified|
|Legacy OnDuelMatched|4 source entries observed by G0|No conversion, unchanged enum=31, marked legacy in code|

Only 1 eligibility predicate has changed at runtime. Prior Skill/Timing/Clash script sources and their existing .meta GUIDs are in Backups/Before_R1/Assets.
