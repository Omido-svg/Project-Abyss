# R9 전용 패치 사용법 및 롤백

## 사용
Unity EditMode의 Battle Test Scene 열기.
Game System Verification > R9 - Start FULL Isolated Regression.
Editor가 28개 Edit Gate와 39개 Play Gate를 수행하며, Play Gate마다 독립적인 PlayMode를 시작·종료한다.
진행 중 중단: Game System Verification > R9 - Abort FULL Regression.
결과 확인: F:\GitCorp\Project-Abyss\ProjectAbyss_R9_Integration_20261102\R9_INTEGRATION_SUMMARY.md 및 R9_GATE_RESULTS.csv.
각 개별 로그는 같은 폴더의 gate_Edit_*, gate_Play_* 참고.

## 로그 정책
Damage.Stagger의 [1029 DMG-07][CONTENT_ERROR] 고정 10/10 동률 오류 1개만 정상 기대값. 같은 오류가 재발생/누락되거나 다른 예외가 있으면 FAIL.
미실행·무출력은 PASS가 아니다. R7 콘텐츠 미이관은 별도 blocker다.

## 롤백
Assets/1. Scripts/Editor/R9/ 아래 신규 4개 .cs와 각각의 .meta 삭제, 폴더 비면 R9.meta도 삭제.
기존 런타임 코드, 원본 스킬 SO/.meta, 프로젝트 씬, 프리팹, Git 상태를 수정하지 않았으므로 기존 파일의 복원은 필요 없다.
기존 프로젝트에 이미 패치 적용됨. ZIP을 다시 설치하지 말 것.
