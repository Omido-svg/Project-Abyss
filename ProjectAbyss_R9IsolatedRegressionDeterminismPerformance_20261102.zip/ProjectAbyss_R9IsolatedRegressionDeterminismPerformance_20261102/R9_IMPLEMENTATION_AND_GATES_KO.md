# Project Abyss — R9 통합 검증 시스템 (2026-11-02)

## 실제 구현
이번 작업은 Unity MCP로 실제 프로젝트의 Editor/R9 경로에 신규 C# 4개를 추가했다. 기존 runtime 코드, ScriptableObject, 메타, 씬은 변경하지 않는다.

1. R9FullRegressionRunner20261102.cs — EditMode 28 Gate + PlayMode 39 Gate를 자동 실행. PlayMode의 각 파괴적 테스트마다 PlayMode를 새로 진입/종료하여 HP·대기열·정적 상태 오염 방지. 각 Gate의 PASS/FAIL/PENDING, 검증 개수, 경과시간, 개별 로그, 전체 CSV/MD 기록. 실행 중단(Abort) 지원.
2. R9CombatReplayAndPerformance20261102.cs — 실제 BattleRuntimeFactory와 ClashManager를 사용한 격리 전투 생성/해제, 동일 시드 결과 해시 일치 비교, Unity Random.state 복원, 12회 측정+2회 워밍업의 성능 기준선. 임의 FPS/SLA를 지어내지 않으며 P50/P95를 비교 기준으로 기록.
3. R9ExpectedDiagnosticPolicy20261102.cs — 의도된 DMG-07 콘텐츠 오류 1건만 Damage.Stagger Gate에서 허용. 다른 Gate의 동일 오류, 예상 밖 오류·예외·중복·누락은 즉시 FAIL.
4. R9ExpectedDiagnosticPolicyVerification20261102.cs — 안전 예외 정책 9개 단위 검사.

## Unity 에디터 메뉴
- Game System Verification > R9 - Run EditMode Regression
- Game System Verification > R9 - Start FULL Isolated Regression
- Game System Verification > R9 - Abort FULL Regression
- Game System Verification > R9 - Seeded Combat Determinism (Play Mode)
- Game System Verification > R9 - Production Battle Performance Baseline (Play Mode)
- Game System Verification > R9 - Expected Diagnostic Fail-Closed Policy (Edit Mode)

**전체 게이트 시작은 EditMode의 Battle Test Scene에서만 지원한다.** 테스트마다 별도 플레이 세션을 진행하므로 스크립트 리컴파일이나 Unity 재시작 중에는 수행하지 않는 것이 좋다. 별도 경고/오류와 단순 무출력 게이트를 PASS 처리하지 않는다.

## 최종 실측 (수정된 실행기 전체 재실행)
- 전체 67/67 Gate PASS, FAIL 0, PENDING 0, 미실행 0.
- EditMode 28개, PlayMode 39개.
- 개별 assertion 1301 PASS, 0 FAIL.
- Damage.Stagger 고정 동률 콘텐츠 오류: expected 1, unexpected 0, 내부 assertion 35/35 PASS. 이전 최초 실행의 일시적 가짜 FAIL은 '예상된 LogError'를 무조건 FAIL 처리하던 분류 문제였음. 현재는 게이트·서명·횟수 단위로 허용.
- R9 Seeded Replay 4/4 PASS. 동일 seed 119831에 대해 결과 SHA-256 동등, 다른 seed와 구분, Unity RNG 원상 복원.
- 성능 3/3 PASS (계측 유효성). 12회 측정(워밍업 2회 제외) P50=5.960ms, P95=6.579ms, MAX=6.579ms. 평균 관리 힙 변화량 약 282965 bytes. 이 값은 테스트 에디터에서의 fixture 생성+진짜 합+해제 측정으로 실제 게임 빌드 프레임 예산이 아니며 별도 SLA/성능 회귀 임계치 미설정.
- 실제 테스트 로그: Reports 아래 R9_GATE_RESULTS.csv, R9_INTEGRATION_SUMMARY.md, gate_Edit_*.log, gate_Play_*.log, R9_DETERMINISTIC_REPLAY.txt, R9_PERFORMANCE_BASELINE.txt.
- G0 정본 파일/.meta 398개 SHA-256 변경 0, 누락 0, 최종 Unity EditMode, Battle Test Scene Dirty 유지/미저장, Git commit/push 없음.

## R9 결과의 정확한 해석
- 위 67개는 현재 정의한 **G0~R8 통합 회귀 묶음**을 모두 실행한 수치다. 프로젝트 내 가능한 모든 테스트나 기획상 미구현 R7 콘텐츠까지 테스트했다고 주장하지 않는다.
- R7 네이티브 완료 확인은 36/145개. 남은 스킬/패시브/63 증강/60 임시 아이템 구현은 R9 통합 실행기가 자동 완성하지 않는다. 정본 수치 미정 1건, 중복 ID 4종은 별도 콘텐츠 blocker로 유지한다.
- G-FINAL에서 전체 필수 콘텐츠 Gate, 실제 빌드 플랫폼 성능 기준, 메모리 누수/프레임 시간 등 추가 검증 및 구조 동결 정책 확정이 필요하다.
- 성능 게이트는 현재 '측정/기준선 검증'이지 정해진 성능 예산에 대한 합격/불합격 시험이 아니다. 기준치는 개발자의 목표 하드웨어/빌드 기준으로 추후 설정해야 한다.
- PlayMode 격리 방식은 Scene Reload/Domain Reload 설정과 실제 Unity 시작 상태에 의존한다. 테스트 기간 Unity 프로젝트 리컴파일은 피한다.

## 패치 반영 및 롤백
- 신규 Editor C# 4개(.meta 포함), R9 폴더 .meta만 추가. 기존 C# 수정 0.
- 로컬 Unity 프로젝트에 이미 적용돼 있으며 ZIP 중복 설치 금지.
- 되돌릴 때 Editor/R9 폴더 및 R9.meta 제거, Unity Refresh. 기존 G0~R8와 SkillDefinition/Prefab/Scene은 건드리지 않음.
