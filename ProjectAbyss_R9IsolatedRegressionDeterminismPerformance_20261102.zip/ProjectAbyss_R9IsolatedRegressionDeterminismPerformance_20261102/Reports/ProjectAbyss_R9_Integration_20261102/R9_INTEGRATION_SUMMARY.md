# R9 integrated regression
- State: COMPLETE_ALL_GATES_PASSED
- Completed gates: 67 / 67
- Gate PASS=67 FAIL=0 PENDING=0 NOT_RUN=0
- Assertions PASS=1301 FAIL=0
- PlayMode isolation: exactly one destructive gate per fresh PlayMode session
- No hidden PASS for no-summary, exception, or skipped gate
- Unresolved R7 content blockers remain tracked by R8 Validator
- EndUTC=2026-11-02T07:38:33.9324307Z
