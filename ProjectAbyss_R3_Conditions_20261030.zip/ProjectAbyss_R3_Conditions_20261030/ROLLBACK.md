# R3 단계만 롤백
1. Unity Play Mode 종료.
2. ZIP ORIGINALS/Assets/... 3개 파일을 원본 Assets/...로 복원: AbilityRunner.cs, SkillEffectDefinition.cs, SkillEffectEntry.cs
3. 신규 Condition/CombatConditionTree.cs, Condition/DamageResultCondition.cs, Editor/Verification/R3ConditionVerification20261030.cs 및 각각의 .meta 파일 제거. 새로 생긴 빈 폴더만 정리.
4. Unity Refresh+Compile, R2 Contract, R1 Trigger Gate, Damage G1 재실행.
R1/R2 및 기존 사용자의 다른 파일 수정은 되돌리지 않는다.
