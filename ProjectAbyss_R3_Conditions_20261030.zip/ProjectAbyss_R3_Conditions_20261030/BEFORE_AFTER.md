# R3 변경 전후
Before: Entry 조건은 선택 이전 context.Target 평가; Definition 조건과 Apply는 Definition.TargetSelector 적용 후 context.Target 사용. 다른 대상 검사 위험과 랜덤 대상 재선정 가능성.
After: Entry에서 Definition.TargetSelector를 딱 1회 사용해 SelectedContext 생성; 그 문맥으로 Entry 조건을 검사; Definition.TryApplyWithSelectedTarget가 같은 대상에 Definition 조건/Apply 실행. 직접 Definition.TryApply(context)는 기존 호출 호환.
Before: AbilityRunner.Plan은 대상 후보별 조건 하나만 입력.
After: 별도 PreTargetCondition과 CandidateCondition 오버로드. 기존 6인자 Plan은 유지.
New: ConditionTree(All/Any/Not/Leaf), ListAdapter(AND), AppliedDamageEvidence(확정 결과의 CauseId/OriginRollUseId/AdditionalHit).
명시적으로 실전 Command Commit이나 DamagePipeline은 변경하지 않음.
