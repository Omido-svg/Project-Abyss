# Project Abyss — R3 ConditionTree/SelectedTarget (2026-10-30)

## 프로젝트
Unity 6000.0.56f1 / Default-Battle-Test / 기준 1546ad3927a99931843853335c89e6d2a9500d9d
문서: 전투 시스템 규칙(1029), Ability 5-Element Roadmap v4.

## 변경 범위
* Assets/1. Scripts/Runtime/Abilities/Conditions/CombatConditionTree.cs (신규)
* Assets/1. Scripts/Runtime/Abilities/Conditions/DamageResultCondition.cs (신규)
* Assets/1. Scripts/Runtime/Abilities/Runtime/AbilityRunner.cs (R2 확장)
* Assets/1. Scripts/Runtime/Skills/Effects/SkillEffectDefinition.cs (선택된 대상 명시적 경로)
* Assets/1. Scripts/Runtime/Skills/Effects/SkillEffectEntry.cs (동일 선택 대상 평가)
* Assets/1. Scripts/Editor/Verification/R3ConditionVerification20261030.cs (+ meta, 신규)

## 변경
1. Null ConditionNode=true(조건 없음); 빈 All=true, 빈 Any=false; Not은 한 자식만 가능.
2. 전투 상태를 직접 변경하지 않는 ICombatCondition 계약. PreTarget을 먼저 검사하고, 선택된 후보별 Candidate 조건을 이후 검사.
3. 원본 피해와 추가타 후속 결과 구분을 위한 AppliedDamageEvidence 및 CauseId 검사. R5 전까지 실전 DamagePipeline은 이 신형 DTO를 만들지 않으므로 아직 프로덕션 전투 연결 아님.
4. 기존 SkillEffectEntry.TryApply의 Entry 조건과 Definition 조건은 한 번 선정한 Target을 함께 평가. Definition.TryApply 직접 호출은 호환.
5. 기존 enum 번호, SO 필드, 상태 저장기, DamagePipeline, UI, 씬 모두 변경 안 함.

## 주의 / 잔여 과제
- R3의 ConditionTree는 C# 구성 기반. 실제 Unity ScriptableObject 조건 저작 UI와 검증기 R8에서 수행 예정.
- R3-K Keyword/Status 질의 및 전문 Store 연결은 미완료.
- 원본 피해/추가타 OriginRollUseId 등의 엔드투엔드 전달은 R5와 통합 시 검증 필요.
- 기존 데이터에서 효과 Entry 102개 모두 CurrentTarget 선택이고, 조건 있는 Entry 6개는 모두 Target Subject로 조사됨.
- 기존 레거시 조건의 분류 및 N/T, Infinity, 미정 수치 전수 검증은 추가 단계 필요.
- GitHub에 커밋/푸시하지 않음. 실제 로컬 Unity의 코드는 이미 직접 수정됨.
- 씬 파일은 저장하거나 되돌리지 않았음. Edit/Play 이후 isDirty=true가 남아 있음.

## 적용
ZIP 내부 고유 최상위 폴더 안의 Assets/ 디렉터리를 Unity 프로젝트 Assets에 병합. 이미 MCP로 수정된 현재 프로젝트에 재적용 불필요.
