# Project Abyss R6-Ia — ReactionQueue/Scheduler 기반 계약
- 기존 R2 ReactionRequest 계약에 BattleReactionScheduler 구현을 추가.
- 반응 의도를 별도 대기열로 보관하며 AfterClashCompleted, AfterActionCompleted 체크포인트만 지원.
- 정렬: checkpoint(호출자 지정) → priority → CauseEventId → EnqueueSequence → RequestId.
- RequestId 중복/재진입 방지, NestedReaction 명시 허용, 깊이·연쇄 수·큐 크기 진단 에러 처리.
- RequestId/ParentActionId/RootActionId/CauseEventId/ChainId/OwnerActorRuntimeId/SkillDefinitionId 보존.
- TryDequeue는 "실행 권한 요청"까지만 하며, ActionResolver/ClashManager를 내부에서 호출하지 않음.
- **미완료:** ActionResolver가 TryDequeue를 호출하고 새 반응 BattleAction을 생성해 PlayMode에서 반격을 수행하는 통합. 히후미 Golden 실전 결과 동등성 및 기존 DelayedEffectTriggerQueue와의 통합. R6-Ib 중간 굴림 삽입 Frame, UI StepTrace도 미완료.
- 기존 동기 히후미 반격을 삭제하거나 변경하지 않았음. R6-Ia 자체 완료/최종 R6 Gate PASS 아님.
- GitHub 커밋/푸시 없음. Unity Editor 로컬에 신규 파일 적용. 씬·SO·기존 전투 파일 변경 없음.