# 복구/설치 안내
이번 차수에는 기존 스크립트 또는 ScriptableObject를 덮어쓴 작업이 없습니다.
신규 파일: Assets/1. Scripts/Editor/Verification/R7NativeMigrationCoverageGate20261102.cs, 대응 .meta.
이 파일 및 .meta를 삭제하면 이번 R7 신규 커버리지 게이트만 제거됩니다.
Unity MCP로 현재 프로젝트에 이미 반영됨. ZIP은 백업/이력 용도로 보관하고 같은 프로젝트에 중복 설치하지 마세요.
원본 Battle Test Scene은 미저장 Dirty 상태로 유지. Git commit/push 없음.
