# Unity MCP live gate results

R7 Legacy Mixed Status 50 PASS, 0 FAIL (2 native damage commits)
R7 Mixed Real Clash 10 PASS, 0 FAIL
R7 Preparation Part Undo 23 PASS, 0 FAIL
R7 Preparation Partless Undo 9 PASS, 0 FAIL
R7 Native Resource 15 Skills 53 PASS, 0 FAIL
R7 Native Bleeding 9 Skills 45 PASS, 0 FAIL
G0 Golden 10 PASS, 0 FAIL
R1 Canonical Trigger 10 PASS, 0 FAIL
Damage G1 46 PASS, 0 FAIL
TOTAL 256 PASS / 0 FAIL. Test overlap exists. Earlier native Preparation implementation was found preexisting and reverified, not rewritten.