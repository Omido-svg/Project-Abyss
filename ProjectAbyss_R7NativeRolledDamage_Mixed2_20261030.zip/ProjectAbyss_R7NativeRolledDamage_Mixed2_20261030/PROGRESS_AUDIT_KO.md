# v4 roadmap approximate progress

Prior estimate approximately 43 percent. Now native R5 DealDamage plus native Bleeding handle both mixed Prestige cards, compared against original results. Approximate weighted effort ~44%, not an official measured gate percentage. Still pending: many bespoke effects, passives/emotions/items, R8 duplicate SkillId, R9 and G-FINAL.