# Native Preparation 이관만 원복
현재 BattleContext.Services.R7PreparationStatusMigration.Enabled = false 로 설정 시 바로 기본 레거시 실행에 복귀. 다른 기존 Resource15/Bleeding9/LegacyMixed7 이관은 유지됨. 이는 현재 전투에만 적용되며 신규 전투는 다시 default ON.
영구 롤백:
1. Unity Play Mode 종료. 다른 작업자 동시 수정 점검.
2. ORIGINALS/Assets 아래 3개의 수정 전 C#을 동일 Assets 경로에 복원. 수정 전 .meta는 변경된 적 없음.
3. 이번 패치 NEW C# 3개 + 각 .meta 파일만 삭제.
4. Unity Refresh/Compile. 준비 스킬/기존 R7·G0·R1·Damage G1 회귀 실행.
5. SOURCE_ASSET_ORIGINALS에는 참고용 SkillDefinition .asset + .meta 원본 바이트를 저장. 실제 에셋은 수정되지 않았으므로 정상 롤백 때 Assets에 덮어쓰지 않음.
6. Battle Test Scene Dirty, 모든 다른 패치, prefab, Timeline 및 Git branch/remote/commit 상태 유지. Commit/push 하지 않음.
