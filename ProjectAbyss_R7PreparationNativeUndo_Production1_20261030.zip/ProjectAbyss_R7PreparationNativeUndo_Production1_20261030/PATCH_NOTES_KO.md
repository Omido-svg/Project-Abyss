# Project Abyss — R7 Preparation Native Bleeding+Burn / Undo / Slot reuse (2026-10-30)

## 이번 실제 프로덕션 이관
기존 Prepared SkillDefinition: SkillId 356e72e97ac84a3a8757d1a188237f43, 원본 SO 전투 태세(도사림), GUID f9c5728c648630849a9ba0afe641d02a.
혈상(Bleeding) + 화상(Burn) 2개의 Legacy AddBodyPartStatusEffect Entry를 실제 R5 네이티브 Command로 변경하고 BattleRuntimeFactory에 DEFAULT ON 등록했다.
원본 세 번째 PreparationFlatSetupEffect Entry는 기존 전문 효과 적용으로 남겨, 방어력 +3 / 이번 턴 합 위력 +1의 정본 결과를 보존한다.
명령 흐름: SkillEffectDispatcher → R7ProductionPreparationStatusMigration → SkillEffectEntry.TryApply 조건/Target/Upgrade → AbilityRunner.Plan → R5PlannedCommandBridge → CombatCommandApplyService → R5CombatSpecialistBackend → BattleEffectResolver → 원본 Character/BodyPart StatusController.
2개 네이티브 Entry의 기존 AddBodyPartStatusEffect.Apply는 재호출하지 않는다. 부분 캐릭터와 부위 없음 Character 앵커 모두 지원한다.

## 중요한 PlanningUndo 동등성
기존 상태와 merge 시 그 상태 인스턴스의 Stack 및 Duration을 snapshot/undo. 신규 상태는 해당 인스턴스만 제거. 원본처럼 상태당 Journal Record 1개이므로 같은 순서·같은 개수의 Undo 동작을 유지한다.
ActionManager는 논리 슬롯을 교체할 때 ActionId를 유지하는데, 이에 맞춰 deduplication/AbilityInstance를 실제 ActionSlot 기준으로 구분한다.
준비 취소 RollbackAll이 기존 Undo를 완료할 때 해당 Slot에 연결된 중복 차단 상태만 Reset한다. 다른 슬롯은 건드리지 않는다.
같은 ActionSlot+ActionId 재실행과 새 ActionSlot이 이전 ActionId를 승계하는 사례 모두 원본 동등성 검증 완료.

## 변경 및 추가
수정 C# 3개, 원본은 ORIGINALS/Assets에 저장:
Assets/1. Scripts/Runtime/Battle/BattleRuntimeServices.cs
Assets/1. Scripts/Runtime/Systems/BattleFlow/BattleRuntimeFactory.cs
Assets/1. Scripts/Runtime/Skills/Base/SkillEffectDispatcher.cs
신규 C# 3개 + 각각 .meta:
Assets/1. Scripts/Runtime/Abilities/Runtime/R7ProductionPreparationStatusMigration.cs
Assets/1. Scripts/Editor/Verification/R7PreparationNativeUndoParity20261030.cs
Assets/1. Scripts/Editor/Verification/R7PreparationPartlessUndoParity20261030.cs

## 경계
기존 Resource15, TempBalance Bleeding9, Mixed Legacy Bleeding7의 네이티브 실행 유지. 이번 새 콘텐츠 이관은 Prepared Skill 한 개의 2개 상태 Entry만 해당. 3번째 FlatSetup 전문 효과는 레거시 실행이며, 총 32개 고유 SkillDefinition의 일부 효과가 네이티브 적용됨.
다른 Preparation의 무기, 특별한 NextTurn/Infinite/Canonical 상태, AutoPlan 전체 흐름, UI/Timeline 최종 QA, R8 중복 ID, R9/G-FINAL 등은 이번 이관에 포함되지 않음.
원본 Scene/Prefab/SkillDefinition SO/.meta 내용 미수정. Git commit/push 없음.
