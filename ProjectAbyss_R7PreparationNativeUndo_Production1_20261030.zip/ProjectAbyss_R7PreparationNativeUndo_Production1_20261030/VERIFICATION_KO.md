# Unity MCP — 실제 Edit/Play Mode 테스트 2026-10-30
Preparation Status Undo Parity: 23 PASS / 0 FAIL
Preparation Partless Undo Parity: 9 PASS / 0 FAIL
R7 7 Legacy Mixed Native Status: 49 PASS / 0 FAIL
R7 9 Native Bleeding: 45 PASS / 0 FAIL
R7 Native Resource Production 15: 53 PASS / 0 FAIL
G0 Golden Baseline: 10 PASS / 0 FAIL
R1 Canonical Trigger: 10 PASS / 0 FAIL
Damage G1: 46 PASS / 0 FAIL
R5 Command Apply Contract: 15 PASS / 0 FAIL
R7 All Skill Migration Readiness: 10 PASS / 0 FAIL
R8 Skill Authoring Validator: 10 PASS / 0 FAIL
합계: 280 PASS / 0 FAIL (일부 계약 중복 검사). Play Mode 각 검증 후 중지.
준비: 최초 1회 혈상/화상 각각 Stack1, 두 번째 사용 Stack2, 2차 취소 시 정확히 Stack1/Duration 복원, 최초 취소 시 모두 제거. Third setup Guard+3, ClashPower+1 양측 동일.
ActionId 재사용 확인 과정에서 초기 커밋 수(전투 시작 선행 준비) 때문에 테스트 기준값이 정확하지 않았고, 원본 Undo Journal count보다 추가 cleanup Record가 많던 점을 발견. 슬롯별 독립 ledger + 기존 하나의 Undo Record에서 복원/cleanup 통합 + 검사 값을 delta 기준으로 수정한 후 최종 23/0을 재실행함.
R5 PASS A12에 'exception'이라는 테스트 설명이 있어 Unity 오류 분류에 잡히는 경우가 있으나, 실제로는 의도적으로 예외를 차단했음을 확인한 Debug.Log PASS 메시지임.
