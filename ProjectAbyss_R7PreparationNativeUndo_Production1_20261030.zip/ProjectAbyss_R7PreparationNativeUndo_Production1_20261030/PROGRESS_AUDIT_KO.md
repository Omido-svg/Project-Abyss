# 로드맵 v4 진행률 판단
직전 비공식 추정 약 43%에서 실제 준비 스킬 1개(Bleeding/Burn 두 상태 Entry, Cancel/Rollback/ActionSlot ID reuse)를 네이티브 R5 Command로 이관. 전체 작업량 기준 약 44%의 매우 거친 수치로 추정. 이는 자동 산출 공식 Gate PASS율이 아니며 PASS 테스트 횟수와 무관.
누적 Content Native 범위: Resource15 + TempBalanceBleeding9 + LegacyMixedBleeding7 + PreparationBleedingBurn1 = 32개의 고유 SkillDefinition에서 특정 효과 일부 네이티브 실행. 전체 145개 전환을 의미하지 않으며 패시브, 아이템, 감정 증강, 복합 효과 대부분, R8 ID 충돌, R9/G-FINAL 미완.
