# R6 코드 변경 전후

|영역|기존|패치 후|
|---|---|---|
| 생산 전투 실행 | 실제 BattleRuntimeFactory의 ActionResolver에서 Stepwise가 기본 OFF | BattleManager 캐릭터 초기화 직후 실제 Stepwise ON |
| 원본 행동 중단/재개 | Stepwise 테스트용 opt-in 실행 가능 | 생산 Resolve coroutine도 각 실제 교환→반응 체크포인트→재개 사용 |
| 교환/타임라인 | 전투 기본 PlayClash 전체 출력 | R6의 PlayCommittedExchange 경유 후 반응 PlayClash, 원본 전체 중복 재생 금지 |
| 반응 요청 수명 | AbilityLifetimeMemory 자료구조 존재했지만 실제 반응 코디네이터 바인딩 없음 | 별도 전투별 ReactionLifetimeRegistry가 요청/시작/실제 적용 3단계 정책을 명시한 요청에 대해서 적용 |
| 히후미 반격 | 레거시 즉시 반격 기본, deferred opt-in 별도 | 실제 등록된 히후미는 R6 deferred 활성; 종료 시 복귀 |
| 히후미 큐 거부 | deferred 큐가 꽉 차면 legacy 즉시 반격 fallback 가능 | deferred에선 절대 즉시 fallback하지 않음; 별도 오류 진단/스케줄 취소 |
| 알 수 없는 commit | 일부 전문 서비스에서 체인 격리 | ActionResolver lifetime도 chain quarantined 처리/재시도 차단 |
| 캐릭터 스킬·R7 | 기존 콘텐츠 | 콘텐츠/Guid 변경 없음; 고유 키워드·컨텐츠별 수명 룰은 R7에서 연결 |
| G0 기준 에셋 | 398개와 .meta 기록 | SHA-256 398/398 일치, 원본 내용/Guid 수정 없음 |
