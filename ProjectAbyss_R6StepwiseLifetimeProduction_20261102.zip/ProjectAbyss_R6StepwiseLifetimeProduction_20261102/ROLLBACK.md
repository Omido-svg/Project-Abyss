# R6 rollback 및 긴급 비활성화

## 런타임 긴급 우회
BattleManager.InitializeBattle() 내 R6ProductionActivation20261102.Activate 호출을 임시 제거/주석 처리하면 기존 생산 경로가 Stepwise=false로 유지된다. 이때 히후미 메커닉은 레거시 동기 모드이며 두 경로를 동시에 사용하지 말 것.

## 완전 원복 (ZIP 내부 원본)
1. Backups/Before_R6/Assets에 저장된 수정 전 **다섯 파일**과 각각의 .meta를 원래 Assets 상대 경로로 되돌린다.
   - 1. Scripts/Runtime/Systems/BattleFlow/BattleManager.cs
   - 1. Scripts/Runtime/Systems/Resolution/ActionResolver.cs
   - 1. Scripts/Runtime/Battle/BattleRuntimeServices.cs
   - 1. Scripts/Runtime/Systems/BattleFlow/BattleRuntimeFactory.cs
   - 1. Scripts/Runtime/Characters/Hifumi/Mechanics/HifumiMechanic.cs
2. 다음 **신규 여섯 파일**의 .cs와 .meta 삭제:
   - R6ProductionActivation20261102.cs
   - R6ReactionLifetimeRegistry20261102.cs
   - R6LifetimeCheckpointVerification20261102.cs
   - R6ProductionStepwiseVerification20261102.cs
   - R6ProductionHifumiActivationVerification20261102.cs
   - R6HifumiQueueGuardVerification20261102.cs
3. Unity Refresh/compile; R6 기존 Edit+Play, R5 Command Apply, R1 Trigger, Damage R1~R7/G1 회귀 실행.
4. Battle Test Scene은 미저장 상태로 보존. SkillDefinition이나 .asset/.meta를 복원·변경할 필요 없다.
5. Git commit/push/reset 없음. 로컬에 이미 적용했으므로 ZIP을 중복으로 설치하지 말 것.
