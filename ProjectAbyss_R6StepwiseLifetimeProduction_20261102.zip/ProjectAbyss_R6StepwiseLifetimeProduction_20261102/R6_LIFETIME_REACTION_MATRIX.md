# R6 수명·반응 처리 계약

## Requested / Started / Applied
- Requested: Scheduler.Queue가 **Accepted를 반환한 뒤** 해당 반응의 수명/쿨다운을 소비한다. 거부된 Queue가 비용/쿨다운을 충전할 수 없다.
- Started: 실제 ClashManager의 반응 결과에 취소되지 않은 교환이 있는 경우에만 소비한다. 큐 등록/타깃 소실/비용 실패는 사용으로 간주하지 않는다.
- Applied: 제작자가 제공하는 실제 커밋 증거 판정이 참일 때만 소비. `ClashResultContext != null` 또는 `Scheduled`만으로 성공 처리하지 않는다. 실재적인 DamageContext나 StatusCommit 근거가 필요하다.
- 메모리는 (ActorRuntimeId, SkillDefinitionId)별로 분리. AbilityLifetimeRules에서 OncePerTurn/Clash/RollUse/OriginHit 및 FullCooldownTurns 정책을 사용.
- Rejected binding으로 남은 RequestId도 coordinator의 MayStart 단계에서 거부하여 우회하지 못한다.
- Specialist deferred callback은 스킬 일반 반응으로 변조하지 않는다. 기존 히후미 굴림 계산기는 그대로 사용하고, 실제 큐 거부 시 즉시 fallback 금지.

## 실제 Stepwise 순서
- Start Action → Exchange 0 커밋 → Exchange 0 시각화 → AfterExchangeSettled(0).
- Exchange 1 커밋 → Exchange 1 시각화 → AfterExchangeSettled(1) → 반응 ActionSlot 실행 및 시각화.
- ResumeAfterCheckpoint() 후 CanContinueRoll 확인; 적 사망/부위 불능이면 이후 굴림 취소.
- Exchange 2 커밋·시각화 → Clash summary → AfterClashCompleted → AfterActionCompleted.
- 반응 ActionId는 parent/root와 다르며, Queue/Registry의 동일 RequestId는 재실행하지 못한다. 기원 ID/연쇄 ID/타깃/조건의 재검사가 필수.
- 만약 전문 서비스가 예외를 던져 미확정 커밋이 발생하면 동일 체인은 격리하고 전투 오류 처리 경로로 전파한다.

## 롤백
기존 5개 파일은 Backups/Before_R6 아래 .cs/.meta 동봉. 새 6개 파일은 삭제. 원본 ScriptableObject/scene에 변경 없음.
