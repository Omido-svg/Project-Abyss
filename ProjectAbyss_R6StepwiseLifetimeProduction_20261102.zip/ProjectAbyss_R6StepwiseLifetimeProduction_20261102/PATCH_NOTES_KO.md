# Project Abyss R6 Lifetime / Reaction — Production Integration (2026-11-02)

## 목표 및 적용 범위
R6 전투 도중 행동 삽입, 원본 합 1교환 단위 중단·재개, 반응 이벤트 시각화 순서, 전투/턴/합/굴림/원인별 수명 정책 및 히후미 반격 이중 실행 안전성을 **실제 BattleManager 초기화 경로**에 연결한다. 기존 ClashManager 굴림/피해 공식, R1~R5 기본 계약, 에셋 GUID, SkillDefinition 데이터는 유지한다.

## 실제 변경 스크립트 (기존 5개)
- BattleManager.cs: InitializeCharacters 완료 직후 R6ProductionActivation20261102.Activate(BattleContext). Battle 종료 서비스 정리 단계에서 Deactivate.
- BattleRuntimeFactory.cs: 각 전투별 새 R6ReactionLifetimeRegistry20261102 생성 후 ActionResolver에 바인딩. 기존 R6 queue/registry와 함께 구성.
- BattleRuntimeServices.cs: ReactionLifetimeRegistry 명시적 수명 서비스/Clone.
- ActionResolver.cs: 생산 Stepwise 활성 여부 조회; R6 checkpoint에서 lifetime CanStart/Complete/Cancel/Quarantine 처리를 실제 반응 실행과 결합. 실행 실패/불명확한 Commit은 재시도하지 않음. 기존 ClashManager.ResolvePair가 실제 전문 서비스 역할을 유지.
- HifumiMechanic.cs: R6 지연 모드에서 반응 큐 거부 시 기존 동기 반격으로 fallback하여 현재 교환을 소급 변경하는 버그 차단. 레거시 즉시 모드 동작은 그대로 유지.

## 신규 스크립트 (6개)
- R6ProductionActivation20261102.cs: 실제 BattleManager 초기화 후 StepwiseSession 활성화, 등록 완료된 히후미 메커닉만 지연 반격 모드로 전환, 전투 종료 시 되돌리기.
- R6ReactionLifetimeRegistry20261102.cs: Request / Started / Applied 수명 소비, 턴·합·RollUse·OriginHit·Cause 중복/쿨다운 제어. Request는 실제 Queue Accepted 후에만 소비. Started는 실제 원본 ClashManager 교환 완료 뒤 소비. Applied는 컨텐츠 제작자가 **실제 적용 증거**에 기반한 판정 콜백을 제공해야 하며, 계획/대기열/결과 라벨만으로 소비하지 않는다. 잘못된 lifetime binding의 큐 우회와 UnknownCommit 연쇄 재진입을 차단한다.
- Editor Verification: R6LifetimeCheckpointVerification20261102 (18), R6ProductionStepwiseVerification20261102 (10), R6ProductionHifumiActivationVerification20261102 (8), R6HifumiQueueGuardVerification20261102 (7).

## 동작 설명
1. BattleManager.InitializeCharacters() → 생산용 R6 stepwise 가동, Hifumi deferred if registered.
2. ClashManager.StepwiseSession.Advance() 하나의 실제 교환 피해/이벤트를 커밋하고 반환한다.
3. ActionResolver.Stepwise: 이미 커밋된 교환 하나를 Timeline에서 보여준 뒤 AfterExchangeSettled 시점에서 반응 대기열을 비운다.
4. 요구된 별도 반응 ActionSlot → R6ReactionActionRegistry 일회성 Take → Lifetime 검사 → 원래 ClashManager.ResolvePair(일방 반격) → 결과와 연출 완결 → 수명 소비. 이후 ResumeAfterCheckpoint()로 남은 원본 굴림의 생존/부위/자원 여부를 재확인한다.
5. 원본 합 전체 종료 때 AfterClashCompleted 및 AfterActionCompleted 시점에서 히후미 특수 반응 등 처리한다. 직접 원본 피해 재실행은 하지 않는다.
6. BattleEnd: 요청/등록/수명 기록/히후미 deferred 상태 모두 정리.

## 안전 및 제한
- 기존 SO 398개 + meta SHA-256 0 변경, scene 'Battle Test Scene' Dirty 유지 및 미저장, Git commit/push 0.
- 지금은 실제 생산 Stepwise 경로가 기본 활성화된다. R6 이전처럼 별도 테스트용 Resolver opt-in에만 머물지 않는다.
- 실제 히후미는 deferral로 전환되어 재생 및 반응 순서를 보존하나, 전체 캐릭터 고유 키워드가 자동 등록된 것은 아니다.
- R6 수명 정책은 **명시적으로 등록한 반응 요청**에 대해서만 제약한다. 콘텐츠별 OncePerTurn/OncePerHit/ConsumeOn 실제 바인딩은 R7 콘텐츠 이관의 책임이다. 등록되지 않은 기존 반응의 의미를 소급 변경하지 않는다.
- 드물게 큐 포화로 반격이 거부되면 중간에 동기 실행하지 않고 안전하게 누락/진단한다. 양호하지 않은 요청도 무조건 성공 처리하지 않는다.
- Unity PlayMode에서 전투 로직·모의 step-presenter의 순서는 검증했으나, 실제 씬의 모든 개별 캐릭터 시각 애니메이션 품질을 육안으로 전수 검사했다는 주장은 하지 않는다.
- R6-Ia request 중복/강제 기원/스킬 소유자/코스트 거짓 완료는 기존 R2/R3/R6 계약을 계속 사용한다.
