# R4 복구 절차 — 원본 씬 저장 금지

1. Backups/Before_R4/Assets 아래 3종 .cs/.meta를 Assets의 동일 경로로 복원:
   - 1. Scripts/Runtime/Abilities/Targeting/R5SlotWeightedTargetBridge.cs
   - 1. Scripts/Runtime/Systems/Resolution/ClashBuilder.cs
   - 1. Scripts/Runtime/Presentation/UI/Panels/BattleWorldSlotArrowOverlayUI.cs
2. 이번에 추가된 6종 .cs와 .meta 제거:
   - R4TargetPlanningRules20261102.cs
   - R4BattlePlanningSession20261102.cs
   - R4ForcedAimAndVisibility20261102.cs
   - R4TargetPlanningContractVerification20261102.cs
   - R4PlanningPreviewParityVerification20261102.cs
   - R4TargetPolicyVerification20261102.cs
3. Unity AssetDatabase Refresh/compile 후 기존 R4LiveSlot, R4Cache, R4Weighted, R5-W, R1/데미지 검증 실행.
4. 기존 ScriptableObject와 .meta GUID, Battle Test Scene, 프리팹은 절대 교체/저장하지 말 것.
5. 보고서는 Assets 외 프로젝트 루트 R4_Target_20261102에 저장되므로 별도 보관 가능. Git reset/commit 없음.