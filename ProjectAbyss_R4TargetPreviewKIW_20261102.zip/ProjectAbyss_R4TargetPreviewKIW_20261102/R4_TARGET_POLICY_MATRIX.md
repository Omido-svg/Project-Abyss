# R4-K/W 계약 및 남은 통합 단계

## W: 실행·미리보기 의미
1. Main target는 기존 공격 ActionSlot/합 조준을 그대로 사용한다. 2차 대상은 같은 hostile side의 실제 TargetableSlot/TargetPoint 후보.
2. 후보 필터 → 안정 정렬 (낮은 main 피지정 수, AreaPriority, SlotOrder, ActorRuntimeId, SlotId, PartId, Generation) → 메인 우선 슬롯 비용 차감 → 마지막 슬롯 부분 배분 가능 → 물리 hit Actor+Part dedup.
3. 여러 선택 슬롯이 같은 일반 몹을 가리켜도 Hit는 몹당 하나, 부위형 몹은 서로 다른 부위별 Hit.
4. R4BattlePlanningSession은 유효한 미리보기 스냅샷을 battle-local로 유지해 R5 opt-in 실행이 재사용. 다른 행동의 조준 변경만으로는 갱신하지 않고 원본 대상/스킬 변경 시 재계산한다.
5. UI는 2차 HitTarget에만 점선을 그리며 ClashPair 또는 공격 가능 ActionSlot을 추가하지 않는다. 표시/조회에서 Unity RNG 소비 0.
6. 사망한 2차 대상은 R5 bridge의 live validation에서 skip. 다른 적으로 자동 리타깃하지 않는다. 대상 소멸 시 확정된 이전 결과 수정하지 않음.

## K: 공통 조준 정책
- IR4TargetPlanningRule: 후보 별 읽기 전용 Allows. 등록 시 기존 BattleContext 배분 무효화. 스텔스/부위차단/잠금/범위 등 정책 소스 등록 가능.
- R4TauntAimPlanner: 입력 적 공격 ActionSlot마다 1개의 도발 소비. 높은 Taunt N 부위 우선, 공격 Speed 높은 행동 우선, N/속도 동률은 정렬 후 고정 seed로 분기. 유효하지 않은 부위는 원래 조준 유지.
- 이번 구현은 ForceAim assignment의 읽기 전용 계산 계약. 실제 Hifumi 상태 스택/명성 은신 Application 감소와 ActionManager 계획 수정은 아직 연결되지 않았음.

## 남은 구간
- R4-K의 히후미/명성 실제 게임 메커닉과의 데이터/플래닝 서비스 바인딩.
- 신규 가중치 활성화된 실전 스킬의 UI 경험 확인, 그 외 R5 다중 피해와 R6 반응 실행의 원자적 결과/동적 스냅샷.
- 기존 SkillDefinition/AttackWeightSettings를 승인 없이 변경하거나 레거시 랜덤 모드를 강제로 변경하지 말 것.