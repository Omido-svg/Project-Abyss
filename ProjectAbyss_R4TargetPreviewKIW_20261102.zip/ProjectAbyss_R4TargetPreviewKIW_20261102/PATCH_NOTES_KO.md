# Project Abyss R4 Target + W/K — 2026-11-02

## 작업 범위
R4 Target / R4-W 슬롯 예산·대상 순서·계획 미리보기 및 R4-K 조준 정책 공통 계약만 수행. 기존 레거시 스킬 에셋, GUID, 전투 데미지 계산기, R5 명령 적용, R6 반응 실행 변경 없음.

## 핵심 연결
- R4TargetPlanningRules20261102.cs: 읽기 전용 조준 후보 필터 및 동일 입력·시드에 대한 안정 정렬/seeded selection. UnityEngine.Random을 소비하지 않음.
- R4BattlePlanningSession20261102.cs: BattleContext별 약한 참조 캐시. 원본 Action/Skill/Target/Part가 같으면 계획과 실행이 정확히 같은 SlotWeighted 스냅샷 공유. 다른 행동의 조준 변경은 배분 유지. 원본 스킬/타깃/강제 타깃/명시적 재계획/정책 변경은 무효화.
- ClashBuilder.cs: BuildAttackWeightPreview read-only 진입점, UI 기존 합 매칭 변경 없음.
- BattleWorldSlotArrowOverlayUI.cs: SlotWeighted를 명시한 플레이어 계획 행동의 추가 피격 대상으로만 은은한 점선 화살표 표시. 메인/합 화살표 유지, 부위 파괴/사망 대상 표시 생략.
- R5SlotWeightedTargetBridge.cs: 실행 시 유효한 R4 계획 스냅샷을 우선 재사용. 없거나 무효하면 기존 결정적 라이브 대상 조회 유지. 피해 자체는 기존 DamageManager가 실행.
- R4ForcedAimAndVisibility20261102.cs: 도발 N은 적 공격 ACTION 단위로 소비(굴림 개수 아님), 높은 N 및 높은 Speed 우선, 동률에 한해서만 seeded RNG. 기존 조준을 직접 변경하지 않는 읽기 전용 분배. 가시성 인터페이스로 부위/슬롯 후보 제외.
- Editor 신규 테스트 3종: 안정 대상 조회(12), 정책(12), 미리보기 실행(22).

## 기능 적용 범위
- R4-W의 계획 미리보기↔실행 대상 동등성은 실제 Unity BattleContext를 이용해 검증.
- 기본 스킬 에셋 중 SlotWeighted 가중치>1 카드가 아직 없어서 정상 플레이 시 점선이 보이지 않을 수 있음. 기존 카드 데이터를 강제로 수정하지 않음.
- 히후미 도발·명성 은신 상태값을 실제 콘텐츠에서 자동 생성/등록하지 않음. R4-K는 순수 정책/조회 계약이며 캐릭터 상태 소스 연결은 별도 작업.
- 반응 스킬과 가중치의 R5 피해 적용 및 R6 프레임/실행 중 동적 타깃 재선정은 이번 패치 범위가 아님.
- 전투 결과 적용 자체는 기존 ClashManager/DamageManager 경로 사용.

## 안전
수정 코드 3개는 Before_R4 아래 원본 .cs/.meta 동봉. 신규 C# 6개(.meta 포함). Unity 프로젝트에는 이미 실시간 적용됨. 씬 저장/프리팹/기존 SO/Git 커밋 없음.