# R4 변경 전후 비교

| 항목 | 이전 상태 | 이번 패치 |
|---|---|---|
| R4LiveSlotQuery | 실제 ActionSlot/TargetPoint 순수 후보 조회 존재 | 그대로 사용, SO/실제 슬롯 추가 없음 |
| SlotWeightedTargetPlanner | 예산, 부분 배분, 히트 단위 중복 제거 존재 | 유지, 테스트 및 미리보기 실전 경로 연결 |
| UI 화살표 | 합/메인 조준 표시만 | SlotWeighted opt-in 카드의 실제 2차 HitTarget을 점선 표시 |
| 실행 스킬 가중치 | R5 bridge가 계획 목록 없이 그때 새로 선택 | 유효한 R4 계획이 있으면 그때 고정된 대상 순서를 그대로 재사용 |
| 다른 행동의 조준 변경 | 정적 cache 테스트만 존재 | 실제 BattleContext에서 동일 계획 revision 유지 확인 |
| 원본 대상/스킬/정책 변경 | cache interface만 존재 | source fingerprint / explicit invalidation / rule registration 구현 |
| 입력 순서가 다른 후보 | 슬롯 계산기 결정론 존재 | 타깃 조회에서 stable ID + 명시 seed 정렬 1000회 검증 |
| K 도발·가시성 | 공통 룰 인터페이스 없음 | 대상별 순수 정책/행동별 도발 분배/부위 필터 계약 |
| 원본 에셋 | G0 SHA-256 398개 기록 | 398/398 asset + meta 변경 0 |
| 실제 데미지 | 기존 DamageManager | 그대로; R5-W 20/20 및 8 damage gates 동등성 |

새 코드에서 R5 기본 피해 계산이나 ActionManager에 2차 가상 행동을 생성하지 않는다.