using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 페이즈 분리와 합 매칭 결과를 조립하는 진입점.
/// 실제 규칙은 ActionPhaseSorter와 ClashMatchPolicy에 위임한다.
/// </summary>
public sealed class ClashBuilder
{
    private readonly ActionPhaseSorter phaseSorter;
    private readonly ClashMatchPolicy matchPolicy;

    public ClashBuilder()
        : this(
            new ActionPhaseSorter(),
            null)
    {
    }

    public ClashBuilder(
        ActionPhaseSorter phaseSorter,
        ClashMatchPolicy matchPolicy)
    {
        this.phaseSorter =
            phaseSorter ??
            new ActionPhaseSorter();

        this.matchPolicy =
            matchPolicy ??
            new ClashMatchPolicy(
                this.phaseSorter);
    }

    public ActionExecutionQueue BuildQueue(
        IReadOnlyList<ActionSlot> slots)
    {
        ActionExecutionQueue queue =
            new();

        List<ActionSlot> prestigeSlots =
            phaseSorter.GetPhaseSlots(
                slots,
                ActionPhase.PRETURN);

        List<ActionSlot> preparationSlots =
            phaseSorter.GetPhaseSlots(
                slots,
                ActionPhase.FORESIGHT);

        List<ActionSlot> combatSlots =
            phaseSorter.GetPhaseSlots(
                slots,
                ActionPhase.COMBAT);

        EnqueueSlots(
            queue.PrestigeQueue,
            prestigeSlots);

        EnqueueSlots(
            queue.PreparationQueue,
            preparationSlots);

        // O-05 「일기토」는 속도순 해결보다 먼저 계획 전체를 보고
        // 같은 상대 슬롯을 노린 다른 아군 슬롯의 '일방타격'을 포기시켜야 한다.
        // ApplyTargetLinks가 계획 TargetSlot 링크를 지우기 전에 표식을 확정한다.
        ApplyPlannedOneSidedSuppression(combatSlots);

        ActionPairingResult pairingResult =
            BuildPairingResult(
                combatSlots);

        // 실제 실행 계획을 만들 때만 슬롯의 TargetSlot 링크를 갱신한다.
        pairingResult.ApplyTargetLinks(slots);

        queue.ClashQueue =
            pairingResult.ToQueue();

        PrintSlots(slots);

        return queue;
    }

    /// <summary>
    /// UI도 실제 전투와 동일한 합 규칙을 사용한다.
    /// 이 메서드는 ActionSlot.TargetSlot을 변경하지 않는다.
    /// 따라서 LateUpdate에서 반복 호출해도 실제 실행 계획을 오염시키지 않는다.
    /// </summary>
    public IReadOnlyList<ClashPair> BuildClashPreview(
        IReadOnlyList<ActionSlot> slots)
    {
        List<ActionSlot> combatSlots =
            phaseSorter.GetPhaseSlots(
                slots,
                ActionPhase.COMBAT);

        ActionPairingResult pairingResult =
            BuildPairingResult(
                combatSlots);

        return new List<ClashPair>(
            pairingResult.Pairs);
    }

    /// <summary>
    /// R4-W opt-in side-target preview. This does not modify pairing, ActionSlots,
    /// skill definitions, or any RNG state. UI and R5-W share a battle-local
    /// frozen allocation for the same planned source action.
    /// </summary>
    public ProjectAbyss.Abilities.R4WeightPlanningPreview BuildAttackWeightPreview(
        BattleContext battle, ActionSlot source, IReadOnlyList<ActionSlot> plans)
    {
        if (battle == null || source?.Skill == null ||
            source.Skill.AttackWeight <= 1 ||
            source.Skill.AttackWeightTargetingModel !=
                ProjectAbyss.Abilities.AttackWeightTargetingModel.SlotWeighted)
            return null;
        IReadOnlyList<Character> hostileSide = null;
        if (source.Owner == battle.Player && battle.Enemies != null &&
            battle.Enemies.Contains(source.TargetCharacter))
            hostileSide = battle.Enemies;
        else if (battle.Enemies != null && battle.Enemies.Contains(source.Owner) &&
                 source.TargetCharacter == battle.Player)
            hostileSide = new Character[]{battle.Player};
        if (hostileSide == null)
            return null;
        return ProjectAbyss.Abilities.R4BattlePlanningSession.Preview(
            battle,source,hostileSide,plans);
    }

    
    public ActionPairingResult BuildPairingResult(
        IReadOnlyList<ActionSlot> combatSlots)
    {
        ActionPairingResult result =
            new();

        if (combatSlots == null)
            return result;

        // 전달받은 목록이 이미 정렬되어 있어도,
        // 외부 호출을 위해 복사 후 실행 순서를 다시 고정한다.
        List<ActionSlot> orderedSlots =
            new();

        foreach (ActionSlot slot in combatSlots)
        {
            if (slot != null)
                orderedSlots.Add(slot);
        }

        orderedSlots.Sort(
            phaseSorter.CompareForExecution);

        HashSet<ActionSlot> usedSlots =
            new();

        foreach (ActionSlot slot in orderedSlots)
        {
            if (slot == null ||
                usedSlots.Contains(slot))
            {
                continue;
            }

            if (!matchPolicy.CanEnterClash(slot))
            {
                result.AddOneSide(slot);
                usedSlots.Add(slot);
                continue;
            }

            ActionSlot targetSlot =
                matchPolicy.FindBestMatch(
                    slot,
                    orderedSlots,
                    usedSlots);

            if (targetSlot != null)
            {
                result.AddClash(
                    slot,
                    targetSlot);

                usedSlots.Add(slot);
                usedSlots.Add(targetSlot);
                continue;
            }

            // 합 상대를 찾지 못한 공격은 속도순 일방 공격으로 남는다.
            result.AddOneSide(slot);
            usedSlots.Add(slot);
        }

        return result;
    }


    private static void ApplyPlannedOneSidedSuppression(
        IReadOnlyList<ActionSlot> combatSlots)
    {
        if (combatSlots == null)
            return;

        foreach (ActionSlot slot in combatSlots)
        {
            if (slot != null)
                slot.SuppressOneSidedResolution = false;
        }

        foreach (ActionSlot source in combatSlots)
        {
            SkillRulebreakerSettings rule = source?.Skill?.Definition?.Rulebreaker;
            ActionSlot plannedTargetSlot = source?.TargetSlot;

            if (rule?.Enabled != true ||
                !rule.SuppressFriendlyOneSidedHitsOnSameTargetSlot ||
                source?.Owner == null ||
                plannedTargetSlot == null)
            {
                continue;
            }

            foreach (ActionSlot other in combatSlots)
            {
                if (other == null ||
                    other == source ||
                    other.Owner != source.Owner)
                {
                    continue;
                }

                if (other.TargetSlot == plannedTargetSlot)
                    other.SuppressOneSidedResolution = true;
            }
        }
    }

    private void EnqueueSlots(
        Queue<ActionSlot> queue,
        IReadOnlyList<ActionSlot> slots)
    {
        if (queue == null ||
            slots == null)
        {
            return;
        }

        foreach (ActionSlot slot in slots)
        {
            if (slot != null)
                queue.Enqueue(slot);
        }
    }

    private void PrintSlots(
        IReadOnlyList<ActionSlot> slots)
    {
        if (!BattleDebugLog.ShowClashBuild)
            return;

        Debug.Log(
            "===== SLOT CONNECTION =====");

        if (slots == null)
        {
            Debug.Log("Slots : NULL");
            return;
        }

        foreach (ActionSlot slot in slots)
        {
            if (slot == null)
            {
                Debug.Log("NULL SLOT");
                continue;
            }

            string log =
                $"Id={slot.ActionId}, " +
                $"Index={slot.ActionIndex}, " +
                $"{GetCharacterName(slot.Owner)} " +
                $"({GetPartName(slot.Part)}) -> " +
                $"{GetCharacterName(slot.TargetCharacter)} " +
                $"({GetPartName(slot.TargetPart)}) / " +
                $"Skill={GetSkillName(slot.Skill)} / " +
                $"Speed={slot.Speed} / " +
                $"Phase={slot.Phase} / " +
                $"TargetSlot={GetTargetSlotText(slot.TargetSlot)} / " +
                $"Clash={(IsConfirmedClash(slot) ? "YES" : "NO")}";

            Debug.Log(log);
        }
    }

    private bool IsConfirmedClash(
        ActionSlot slot)
    {
        if (slot?.TargetSlot == null)
            return false;

        return
            slot.TargetSlot.TargetSlot == slot &&
            matchPolicy.CanEnterClash(slot) &&
            matchPolicy.CanEnterClash(
                slot.TargetSlot);
    }

    private string GetCharacterName(
        Character character)
    {
        if (character == null)
            return "NULL";

        return character.Data == null
            ? character.name
            : character.Data.CharacterName;
    }

    private string GetPartName(
        BodyPart part)
    {
        return part == null
            ? "NONE"
            : part.Type.ToString();
    }

    private string GetSkillName(
        Skill skill)
    {
        return skill == null
            ? "NULL"
            : skill.SkillName;
    }

    private string GetTargetSlotText(
        ActionSlot targetSlot)
    {
        if (targetSlot == null)
            return "NULL";

        return
            $"{GetCharacterName(targetSlot.Owner)} " +
            $"({GetPartName(targetSlot.Part)}) " +
            $"[Index={targetSlot.ActionIndex}, Id={targetSlot.ActionId}]";
    }
}
