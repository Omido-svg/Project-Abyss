# Project Abyss R4-Wc: 실제 대상 슬롯 조회 + 계획 스냅샷 캐시 (2026-10-30)

기반: R1/R2/R3 및 R4-Wa/b 선택기 패치.

추가 파일:
- Assets/1. Scripts/Runtime/Abilities/Targeting/R4LiveSlotQuery.cs
- Assets/1. Scripts/Runtime/Abilities/Targeting/R4PlanningAllocationCache.cs
- Assets/1. Scripts/Editor/Verification/R4LiveSlotQueryVerification20261030.cs
- Assets/1. Scripts/Editor/Verification/R4PlanningSnapshotCacheVerification20261030.cs

주요 내용:
1. 실제 ActionSlot, CharacterData.ActionSlots, BodyPart.PartId, GetTargetPoints 읽기 전용 연결.
2. 정예 적 미설정 추가 부위도 TargetPoint 어댑터로 표현하고, 부위 없는 일반 적은 Actor 단위 타깃으로 표현. 가상의 실행 행동을 생성하지 않음.
3. ActionSlot.TargetSlot과 실제 DamageTargetPart는 서로 독립. 실제 유효 부위 검증 후 메인 슬롯 결정.
4. 조준 점유 수는 계획 ActionSlot의 메인 타깃만 집계. TargetSlot이 명확하지 않아 여러 후보에 걸치면 임의 배정하지 않고 진단 출력.
5. 런타임 Actor ID는 Unity GetInstanceID를 uint로 매핑한 세션 내 식별자; 전투를 넘나드는 영속 ID 아님.
6. 슬롯 비용 기본 1, AreaPriority 기본 0은 실제 콘텐츠에 필드가 아직 없는 임시 조회 정책으로 분리. SO 콘텐츠 수치 변경 없음.
7. 다른 행동 조준만 바꾸면 현재 ActionId 스냅샷 보존; 자기 스킬/대상/가중치 정책/명시적 재계획 시 무효화. 현재 UI/ActionManager는 이 캐시를 아직 호출하지 않음.
8. 기존 ClashBuilder, AttackWeightTargetResolver, DamageManager, SkillDefinition, 씬과 프리팹 변경 없음.

미완료: ActionManager와 계획 Presenter에 캐시 수명 바인딩, 실제 공격 가중치 옵트인 필드/비용/AreaPriority 콘텐츠 확정, R5-W DamageBatch 실전 경로, R4-I 반응 조준.

Git 커밋/푸시 없음. Unity Editor에 파일이 이미 적용됐으므로 ZIP 재적용 불필요.