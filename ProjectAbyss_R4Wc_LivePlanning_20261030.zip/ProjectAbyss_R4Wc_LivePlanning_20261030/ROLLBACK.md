# R4-Wc 단독 롤백
Unity Play Mode 종료 후 본 ZIP에 포함된 신규 C# 4개와 각각의 .meta를 삭제한 뒤 AssetDatabase Refresh/Compile. 기존 R4-Wa/b 파일 및 R1/R2/R3은 그대로 보존. 씬은 저장 또는 되돌리지 않음.