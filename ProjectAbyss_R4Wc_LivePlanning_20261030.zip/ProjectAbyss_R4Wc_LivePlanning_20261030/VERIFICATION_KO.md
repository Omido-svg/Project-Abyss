# R4-Wc 검증 기록
Unity Play Mode: R4 - Live Slot Query PASS=16 FAIL=0
Unity Edit Mode: R4 - Planning Snapshot Cache PASS=13 FAIL=0
기존 R4-Wa/b: PASS=18 FAIL=0
기존 R1: PASS=10 FAIL=0, G0 Golden PASS=10 FAIL=0, Damage G1 PASS=46 FAIL=0.

테스트 시 실제 Battle Test Scene 정예 적은 부위 5개/설정 행동 슬롯 4개, 일반 적 2명은 각각 부위 없는 타격점 1개. 읽기 전용 조회로 정예 적 extra part, 서로 다른 실제 대상/조준 슬롯, 조준 점유, 진영 목록 제한, 결정론/RNG 미소모를 확인.

주의: 이는 Play Mode 조회 스모크 및 캐시 정책 테스트. 실전 플레이어 조작/계획 UI/공격 가중치 DamageBatch 연결 완료를 의미하지 않음.