# 전체 v4 로드맵 진척 (2026-10-30)
이전 대화의 비공식 추정 약 38%에서, 이번에는 **15개 실제 프로덕션 SkillDefinition**의 단일 자원 효과군 3종을 Legacy Definition.Apply가 아닌 R5 네이티브 Command 적용으로 전환했다.
단순 R7 '후보 68개'나 브리지 테스트와 달리 이번 15개는 기본 BattleRuntimeFactory에 등록되어 DEFAULT ON으로 실제 게임 전투에서 활성화된다. 안정성 검증은 15개 직접 Dispatcher 비교와 대표 Preparation ClashManager 실제 전투 결과 비교를 포함한다.
R7 미완: 원본 145개 스킬 중 나머지 일반/결투/준비/위세 효과, 캐릭터 메커닉/반격, 패시브/감정/아이템, 복합 Effect, 출혈·피해 Command, 전체 콘텐츠와 UI/TL Golden.
작업량 추정은 약 40%로만 소폭 상향하는 것이 보수적이다. 자동 측정된 공식 PASS율은 아니다.
