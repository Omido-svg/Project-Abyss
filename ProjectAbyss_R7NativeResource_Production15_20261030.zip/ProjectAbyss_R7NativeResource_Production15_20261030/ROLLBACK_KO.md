# R7 실제 네이티브 Resource 이관 단독 롤백
빠른 런타임 롤백: 현재 BattleContext.Services.R7NativeResourceMigration.Enabled=false; 이렇게 하면 전투의 15개 대상도 기존 SkillEffectDispatcher.ExecuteEntries로 즉시 복귀. 새 전투에 적용되려면 아래 코드 롤백 필요.

코드 롤백:
1. Unity Play Mode 종료. 다른 사용자/에이전트 동시 코드 변경 여부 확인.
2. ZIP ORIGINALS/Assets/...에 보존한 아래 여섯 파일을 동일 Assets 상대 경로에 복원:
 SkillEffectDefinition.cs, SkillEffectEntry.cs, R7ExclusiveEntryMigrationScope.cs, BattleRuntimeServices.cs, BattleRuntimeFactory.cs, SkillEffectDispatcher.cs.
3. ZIP Assets에 포함된 신규 R7NativeResourceCommandExecutor.cs, R7ProductionNativeResourceMigration.cs, R7NativeResourceMigrationVerification20261030.cs, R7Production15NativeMigrationVerification20261030.cs, R7ProductionActualClashVerification20261030.cs 및 각 .meta 파일만 삭제.
4. Unity Refresh + Compile. R5 Contract, R7 기존 Effectful Batch, G0/R1, Damage G1 재실행.
5. ZIP SOURCE_ASSET_ORIGINALS/의 15개 .asset/.meta는 검증/향후 복원 참고용. 이번 패치로 SO가 수정되지 않았으므로 원 프로젝트 Assets에 덮어쓸 이유가 없다.
6. 다른 R1~R7 패치/씬/프리팹/에셋/Git 변경은 되돌리지 말 것. Git commit/push 금지.
