# Project Abyss — R7 실제 프로덕션 네이티브 Resource Command 이관 (2026-10-30)

## 이번 패치가 실제로 완료한 범위
BattleRuntimeFactory에 R7ProductionNativeResourceMigration을 DEFAULT ON으로 생성한다. 안전성이 확인된 고유 SkillId 15종 (올라프/유진/공통)의 단일 TempBalance Resource 효과가 현재 게임의 SkillEffectDispatcher를 통해 **실제 AbilityRunner.Plan → R5PlannedCommandBridge → CombatCommandApplyService → R7NativeResourceBackend → Character 정식 자원 API** 경로로 처리된다.
변경된 세 효과군: GainBlock (방어력), GainPrestige (위세), TurnClashPowerBonus (이번 턴 합 위력).
명시적 리소스 명령의 적용 결과가 확인된 경우에만 ActivationKey에 Commit한다. 이관 대상의 TempBalanceSkillProxyEffectDefinition.Apply()는 호출하지 않는다. 레거시와 신규 효과가 동시에 적용되지 않는다.
프로덕션 전투에서 기존과 같은 결과를 보존하도록 대상 카드의 SkillId, Asset GUID 참고 매핑, 실제 에셋 이름, OnExecute/OnExchangeWin의 정본 트리거, 단일 Entry, 기대 Operation을 검증한다. 부합하지 않는 자산은 기존 효과 경로로 처리된다.
R7ProductionNativeResourceMigration은 BattleRuntimeServices를 통해 전투마다 소유하며 생성/복원 시 이전 인스턴스를 Dispose한다. 문제가 생기면 현재 전투의 context.Services.R7NativeResourceMigration.Enabled=false로 즉시 Legacy 동작을 복원할 수 있다.
현재 운영에서 이관된 스킬의 실제 .asset/.meta는 수정되지 않았다. GUID/기존 저장 호환성을 유지한다.

## 수정 코드 (ZIP ORIGINALS/Assets/...에 수정 전 사본)
Assets/1. Scripts/Runtime/Skills/Effects/SkillEffectDefinition.cs
Assets/1. Scripts/Runtime/Skills/Effects/SkillEffectEntry.cs
Assets/1. Scripts/Runtime/Abilities/Runtime/R7ExclusiveEntryMigrationScope.cs
Assets/1. Scripts/Runtime/Battle/BattleRuntimeServices.cs
Assets/1. Scripts/Runtime/Systems/BattleFlow/BattleRuntimeFactory.cs
Assets/1. Scripts/Runtime/Skills/Base/SkillEffectDispatcher.cs

## 신규 파일 (.meta 포함)
Assets/1. Scripts/Runtime/Abilities/Operations/R7NativeResourceCommandExecutor.cs
Assets/1. Scripts/Runtime/Abilities/Runtime/R7ProductionNativeResourceMigration.cs
Assets/1. Scripts/Editor/Verification/R7NativeResourceMigrationVerification20261030.cs
Assets/1. Scripts/Editor/Verification/R7Production15NativeMigrationVerification20261030.cs
Assets/1. Scripts/Editor/Verification/R7ProductionActualClashVerification20261030.cs

## 안전 경계
- 기본 게임으로 실제 활성화된 범위는 정확히 15개의 고유 스킬·3종 Resource 효과이며, 나머지 약 130개 SkillDefinition·상태이상·출혈·피해·캐릭터 특수 조합은 Legacy 처리 유지.
- 기존 R7ExclusiveEntryMigrationScope는 별도로 명시 Opt-in 하는 실험 코드. 기본 프로덕션은 이와 독립적이며 R7 전용 네이티브 서비스가 처리.
- **기존과 효과 상태 결과가 다를 수 있는 경계:** 자원 상한에 도달해 실제 증가가 0인 명령은 네이티브 적용 결과를 실패로 기록한다. 기존 TempBalance SO의 void Apply()는 별도의 결과 확인 없이 Applied를 반환하는 방식이다. 무효 변경 상태의 골든 동등성 및 모든 버프/스테이터스 조합은 추가 검증 필요.
- 실제 ClashManager는 common.preparation.crouch에서 현재 기존 Legacy와 신규 모두 +16(두 실행)을 확인. 기획상 두 번 적용이 정본인지 추가 검토 필요. 이관으로 새 중복이 생긴 것은 아니며 수치/교환 수 동등성 확인.
- R7 전체 완료 아님. AbilityRunner가 모든 Skill/Passive/Emotion/Item을 처리하거나 모든 85 EffectEntry를 Native 적용하도록 전환한 것이 아니다.
- R8 중복 SkillId 4종/8 assets 차단 유지. 고유 GUID 변경/저장/Scene/Prefab/Timeline 편집 없음. Git commit/push 없음.
