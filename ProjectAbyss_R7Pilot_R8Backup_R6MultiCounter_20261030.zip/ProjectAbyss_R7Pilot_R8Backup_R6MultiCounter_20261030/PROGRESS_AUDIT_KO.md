# v4 전체 MD 진행률, 2026-10-30
이전 종합 실무 가중 추정 약 35%에서 이번 R7 no-effect 실제 SkillDefinition→AbilityInstance→AbilityRunner event pilot과 R8 원본 무결성 백업/복원 도구, R6 다중 반격 Golden 범위 확장을 반영해 **약 36%로 소폭 상향 추정**.

이것은 자동 측정치가 아닌 엔지니어링 작업량 추정이다. 실제 R7 스킬 효과 이관은 여전히 0건, 대형 통합 미완료이므로 36%는 정식 Gate PASS율이 아니다. R8 4개 중복 SkillId(8개 에셋) 블로커 미해결. 향후 우선순위는 R7 실제 효과가 있는 카드 1개 수직 이관과 엄격한 이중 적용 차단, 중복 ID 해결, R6 Hifumi Goldan/Catastrophe/Timeline Golden 및 R9.
