# Project Abyss — R7 실제 스킬 식별 파이프라인 / R8 Immutable Backup / Hifumi 다중 반격 회귀 (2026-10-30)

## 적용 코드
MODIFIED (기존 .meta는 보존):
- Assets/1. Scripts/Editor/Verification/R6HifumiDeferredParityVerification20261030.cs
- Assets/1. Scripts/Editor/Verification/R7SkillMigrationDryRun20261030.cs

NEW (+ 각각 .meta):
- Assets/1. Scripts/Runtime/Abilities/Runtime/R7SkillPilotObserver.cs
- Assets/1. Scripts/Editor/Verification/R7SkillPilotObserverVerification20261030.cs
- Assets/1. Scripts/Editor/Verification/R8PilotAssetBackupGate20261030.cs

## R7 실제 런타임 파일럿
R7SkillPilotObserver는 BattleEvent.OnActionStart에서 실제 스킬 Action/SkillDefinition과 보존된 GUID를 읽고 AbilityIdentity(DefinitionId, OwnerRuntimeId, SourceSlotId, EntryIndex)와 AbilityInstance를 생성한다.
AbilityRunner.Plan(AttackResolutionStarting)을 실제 호출하지만 no-effect NormalAttack 범위에서 Commands=0 / AppliedCommands=0을 강제한다. 실전 굴림·피해·리소스는 기존 ClashManager와 Skill로만 처리한다.
AssetCatalog 전체 중 동일 SkillId가 중복되면 등록 차단. 루트 효과, per-roll OnWin/OnLose/공통 효과, MultiRollPenalty 효과, 캐릭터 전용 히후미, 활성 Rulebreaker/특수 리소스 등의 위험 항목은 파일럿에서 제외한다.
옵저버는 명시적으로 생성/Dispose할 때만 구독하며 기본 전투 서비스에는 자동 설치되지 않는다.
실제 test_normal_swipe 액션을 실행해 Baseline HP 피해 48 vs Pilot HP 피해 48을 확인했다(동일 난수 상태).

## R8 원본 무결성 보존
9개 안정 후보의 원본 .asset + .meta = 총 18개를 프로젝트 바깥이 아닌 프로젝트 루트 아래의 전용 backup 폴더(Assets 외부)에 그대로 복제하고 SHA-256으로 바이트 대등성을 검증.
원본 GUID가 AssetDatabase 왕복 조회와 일치하는지 확인. 백업이 이미 존재하지만 원본과 다르면 자동 덮어쓰기 금지. BACKUP_MANIFEST.csv/RESTORE_POLICY_KO.md 생성.
현재 R8 전체 이관 승인 Gate는 중복 SkillId 4종(8개 에셋) 때문에 BLOCKED 유지. 이번 backup은 이관 허가가 아니며 SO를 실제 수정하지 않는다.

## R6 다중 반격 Golden 확장
Hifumi_Test 런타임 두 개를 동일 RandomState로 실제 반격 실행:
- 한 굴림 피해 7/7, Event power 7/7
- 두 굴림 피해 13/13, Counter event sequence index 0,1 및 위력 7,6 대등
- 지연 실행 전 상대 HP/ReactiveRollEvent 변화 없음; 체크포인트 이후 1회, 재실행 불허
기존 히후미 기본 동작은 Legacy 즉시 실행. R6 Opt-in 사용 시에만 지연.

## 검증 범위와 미완료
이번 Unity MCP 실제 Gate 묶음 259 PASS / 0 FAIL(테스트 내용 일부 중복).
R7 no-effect 스킬 능력 식별/계획 파이프라인만 통과했으며, 효과 있는 스킬의 새 AbilityRunner 커맨드 적용 및 기존 SkillEffectDispatcher 독점 전환은 **아직 미완료**.
R8 전체 콘텐츠 이관/ID 중복 해결/승인 기반 수정은 아직 미완료.
Hifumi 골단 만개·대실패 추가 반격·적 반격병 전체 Golden은 아직 미완료.
R6-Ic 완성 Timeline 카메라/모션 연속성 QA는 아직 미완료.
Prefab, Scene, Timeline, SO 원본 변경 없음. GitHub commit/push 없음.
