# 본 패치만 안전하게 롤백하는 방법
Unity Play Mode 종료 후 다른 사용자/에이전트의 파일 동시 수정 여부 확인.

1. ORIGINALS/Assets/...의 R6HifumiDeferredParityVerification20261030.cs 및 R7SkillMigrationDryRun20261030.cs를 Assets/ 원위치로 복원.
2. NEW 3종(R7SkillPilotObserver.cs, R7SkillPilotObserverVerification20261030.cs, R8PilotAssetBackupGate20261030.cs)과 각각 .meta 삭제.
3. Unity Refresh/Compile, 이전 R6,R7,R8 Gate 재검증.
4. R8_PILOT_BACKUPS/ 안의 원본 asset/meta는 사용자 승인 없이 프로젝트 Assets에 복사하지 말 것. 이들은 보존용이며 이번 작업이 수정하지 않은 SO의 오리지널 바이트다.
5. Git/씬/프리팹/TL 등의 별도 작업 변경분은 유지.
