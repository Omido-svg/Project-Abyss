BEFORE: AttackWeightTargetResolver는 캐릭터 수 기반 레거시 랜덤 부가타깃 선정. R4 슬롯 가중치 선택기는 계산기와 라이브 조회까지만 연결되어 있었다.
AFTER: AttackWeightSettings.TargetingModel이 SlotWeighted인 경우 기존 Resolver가 R5SlotWeightedTargetBridge를 호출해 결정론 슬롯 예산으로 타깃을 선정하고 기존 DamageManager 결과 처리에 전달한다. Default=LegacyCharacterRandom; 기존 SO와 스킬은 동작 유지.
실제 HP/부위 내성 계산이나 ClashManager 피해 경로를 새로 작성하지 않았다.
