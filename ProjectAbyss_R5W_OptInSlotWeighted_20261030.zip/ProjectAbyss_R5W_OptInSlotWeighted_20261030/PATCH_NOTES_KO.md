# Project Abyss — R5-W 슬롯 가중치 실제 대상 해석 패치 (2026-10-30)

기준: 기존 R1/R2/R3/R4-W/R4-Wc/R5 기본 계약 적용된 Unity 로컬 프로젝트.
이 ZIP은 실제 전투 대상 선정 경로의 opt-in 구현이며, 전체 R5/R1~R9 최종 PASS는 아님.

## 수정 파일
- Assets/1. Scripts/Runtime/Battle/Targeting/AttackWeightSettings.cs
- Assets/1. Scripts/Runtime/Skills/Base/Skill.cs
- Assets/1. Scripts/Runtime/Battle/Targeting/AttackWeightTargetResolver.cs

## 신규 파일
- Assets/1. Scripts/Runtime/Abilities/Targeting/R5SlotWeightedTargetBridge.cs (+.meta)
- Assets/1. Scripts/Editor/Verification/R5SlotWeightedIntegrationVerification20261030.cs (+.meta)

## 구현
- 공격 가중치 설정에 TargetingModel 옵션 추가. 기본값 LegacyCharacterRandom=0. 기존 SO 직렬화 호환.
- Skill.AttackWeightTargetingModel 가상 속성 추가.
- AttackWeightTargetResolver.ResolveTargets에서 SlotWeighted일 때만 신규 R5SlotWeightedTargetBridge 호출.
- 타깃 후보는 R4LiveSlotQuery의 실제 타깃 가능 슬롯 + 부위로 구성. 실제 현재 해석 대상(action.Target/TargetPart)을 메인으로 고정.
- 동일 Actor/Part를 여러 슬롯으로 조준해도 1회 대상 선정. 정상/약화 부위와 부위 없는 적 지원.
- 실패한 슬롯 계획은 메인만 남기고 무작위 레거시 fallback 금지.
- 공격·합 굴림은 기존 ClashManager, 보조 피해는 기존 DamageManager.ApplyAttackWeightDamageContext 및 AttackWeightHitResult 경로 그대로.
- R4SlotWeightedTargetPlanner는 난수를 소모하지 않고 가중치 예산·우선순위·부분 배정만 계산한다.
- 현재 모든 실제 SkillDefinition은 기본 AttackWeight.Weight=1이므로 SO를 강제로 opt-in 하지 않았음.

## 남은 작업
- 계획 UI/R4PlanningAllocationCache가 실제 ClashBuilder 및 스킬 실행에 완전히 연결되지 않아, 새 경로의 배정은 행동 처음 실행 시 확정됨.
- `AnotherPartOnPrimaryCharacter` 등 레거시 명성 전용 스킬을 자동 이관하지 않았음.
- 반응 행동/중간 사망·슬롯 파괴/교환 도중 리타깃과 계획 취소/실제 ActionManager 스냅샷에 대한 모든 사례 검증은 추가 필요.
- 이 패치의 테스트는 Play Mode 임시 스킬로 대상 경로+DamageManager 호출을 검사했으며 완전한 실제 ClashManager.ResolvePair의 슬롯 가중치 시나리오 테스트는 아님.
- UI, Presentation, DamageManager, DamagePipeline, ClashManager, Scene, Prefab, ScriptableObject 에셋 내용 변경 없음.
- GitHub commit/push 없음. Unity Editor에는 실제로 코드가 이미 적용됨.

## 적용
고유 최상위 폴더 안 Assets/ 디렉터리를 프로젝트의 Assets/에 병합. 현재 사용자 로컬 프로젝트에는 이미 반영됐으므로 중복 복사 불필요.
