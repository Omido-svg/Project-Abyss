# R5-W 단독 롤백
1. Unity Editor Play Mode 종료 및 병행 수정 여부 확인.
2. ZIP ORIGINALS/Assets/...의 3개 수정 전 C# 파일을 원래 Assets/... 위치로 복원한다.
3. 신규 R5SlotWeightedTargetBridge.cs, R5SlotWeightedIntegrationVerification20261030.cs 및 두 .meta만 제거한다.
4. Unity Refresh/Compile, G0 Golden, R1, Damage G1, R4 계약 검사 수행.
5. 다른 R1~R5 패치/씬·프리팹·SO는 되돌리지 않음.
