# Unity MCP 실측 검증 — 2026-10-30
- R5-W Slot Weighted Live Hit Batch (Play Mode): 20 PASS / 0 FAIL.
  기본 모드 보존, 정확한 메인·2서브 선정, actor/part 중복 배제, Unity Random 불변, 동일 행동 캐시,
  엘리트 부위 5개 및 일반 적 2명 처리, 부적격 진영 실패, 불분명 부위 메인만 유지,
  실제 DamageManager.ApplyDamageContext 및 ApplyAttackWeightDamageContext 호출, DamageResult 원장 기록 검증.
- 기존 G0 Golden 10 / 0, R1 Trigger 10 / 0, Damage G1 46 / 0.
- 기존 R2 계약 7 / 0, R3 조건 17 / 0, R4 Planner 18 / 0,
  R4 Cache 13 / 0, R4 Live 16 / 0, R5 Command Contract 15 / 0,
  R5 real specialist 12 / 0, R5 Plan→Apply 12 / 0.
- 합계 이번에 다시 실행한 검사들의 결과 196 PASS / 0 FAIL.
- Unity Console error 0; Play Mode 종료; C# 컴파일 정상.

검사 수를 전체 전투 시스템의 196개 독립 요구사항으로 해석하면 안 됨. R5-W 최종 Gate는 미완료.
