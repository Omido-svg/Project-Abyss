# Project Abyss — R1 Trigger / Duel Gate Stage A+B (2026-10-30)
기준: Default-Battle-Test @ 1546ad3927a99931843853335c89e6d2a9500d9d
문서: 전투 시스템 규칙(1029), Ability 5-Element Roadmap v4

## 적용 내용
- 기존 ScriptableObject enum 번호 0~34 보존; 새 공격해결시작=35, 도사림발동=36 추가
- 신규 카드 Authoring에서 OnDuelMatched(31) 제외, 기존 값/레거시 실행 경로 유지
- DataNormalSkill / DataDuelSkill: OnExecute를 행동당 1회가 아닌 실제 굴림마다 1회로 분리
- ClashManager: 합 교환 및 일방 굴림마다 사용시 발동, 재굴림에서는 추가 발동하지 않음
- Skill.NotifyRollOutcome: 일방타격을 교환 승리/패배로 세지 않음
- BattleAction: 최초 듀얼-대-듀얼 효과 게이트를 행동에 기록, 남은 일방타격에서도 유지
- Skill: 결투 효과 게이트를 모든 Definition/명시적 효과 파이프라인으로 확대
- DataPreparationSkill: 신규 OnPreparationActivated 진입점 추가, 기존 OnExecute 호환 유지
- R1AbilityTimingVerification20261030: Play Mode 메뉴 검증 추가

## 실제 수정/추가 파일
Assets/1. Scripts/Runtime/Battle/BattleAction.cs
Assets/1. Scripts/Runtime/Skills/Base/Skill.cs
Assets/1. Scripts/Runtime/Skills/DataDriven/DataNormalSkill.cs
Assets/1. Scripts/Runtime/Skills/DataDriven/DataDuelSkill.cs
Assets/1. Scripts/Runtime/Skills/DataDriven/DataPreparationSkill.cs
Assets/1. Scripts/Runtime/Skills/Effects/SkillEffectTiming.cs
Assets/1. Scripts/Runtime/Systems/Resolution/ClashManager.cs
Assets/1. Scripts/Editor/Verification/R1AbilityTimingVerification20261030.cs (+ .meta)

## 주의 / R1 남은 작업
- 기존 Olaf_D_11, D_12, D_14, D_15에 OnDuelMatched override Entry 총 4개: 레거시로 유지.
  최신 1029 카드 문구와 대조한 수동 콘텐츠 마이그레이션 전에는 삭제/의미변경 금지.
- 기존 비데이터 스킬/전용 캐릭터 기믹들의 '카드 효과' 경로 일괄 이관은 미완료.
- R1 로드맵의 동률 재굴림 강제 시나리오/중간 슬롯 파괴/실행 도중 타입 변경까지 전수 검증하지 않음.
- 최종 G0~R9 Gate는 아직 PASS 아님. 현재 제공되는 것은 검증된 R1 중간 단계(A+B)다.
- 전투 씬은 기존 Play Mode 검증 후 미저장 상태(isDirty=true). 이 패치는 씬 파일을 포함하지 않음.
- GitHub 커밋/푸시 없음. 사용자 로컬 Unity Editor에 동일 런타임 파일이 직접 변경됨.

## 적용
Unity 프로젝트 루트에 ZIP 내부의 ProjectAbyss_R1_CanonicalTiming_20261030/Assets/ 이하를 Assets/에 맞춰 복사. 
이미 MCP로 패치가 적용된 로컬 프로젝트에 중복 덮어쓸 필요는 없음.
ZIP의 ORIGINALS/는 롤백용 원본이므로 Assets/에 자동 병합하지 말 것.
