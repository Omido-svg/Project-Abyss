# Before / After
| 상황 | 이전 G0 관측 | R1 A+B 실제 관측 |
|---|---:|---:|
| 3굴림 평타 OnExecute (사용시) | 1 | 3 |
| 결투 vs 결투 3굴림 OnExecute | 1 | 3 |
| 평타 일방 3굴림 OnExchangeWin | 3 | 0 |
| 결투 vs 평타, 결투 OnExecute | 기존 불확실/카드당 1 호출 | 0 |
| 결투 vs 평타, 결투 OnClashEnd | 1 | 0 |
| 결투 vs 평타, 결투 AfterDamage | 1 | 0 |
| 추가타 AfterDamage(원본) | 1 | 1 |
| Legacy Weight=3 서브 피해 | 2 | 2 |
| 기존 OnDuelMatched 3굴림 관측 | 3 | 3 (레거시 호환) |

R1 새 경로:
ClashManager.ExecuteSkillOnce(): 1회 시작 → Skill.NotifyAttackResolutionStarting()
매 실사용 굴림: Skill.NotifyRollUsing() → OnExecute 효과 (기존 데이터 스킬에 적용)
맞붙은 교환만: Skill.NotifyRollOutcome() → OnExchangeWin/Lose
듀얼 카드 효과: BattleAction.DuelEffectsEligible 게이트 (최초 매칭 결과)
기존 데미지 적용: DamageManager / DamagePipeline 변경 없음
UI / Presentation 관련 파일: 변경 없음

미확정 수치를 코딩으로 확정하지 않았으며 직렬화 번호/기존 GUID는 그대로 보존함.
