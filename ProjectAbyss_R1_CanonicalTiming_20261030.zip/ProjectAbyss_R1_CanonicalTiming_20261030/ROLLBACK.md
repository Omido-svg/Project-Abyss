# R1 A+B 단독 롤백
1. Unity Editor Play Mode가 종료된 상태에서 원본 스크립트의 안전한 별도 백업을 확인한다.
2. 본 ZIP의 ORIGINALS/Assets/... 폴더 내용만 Unity 프로젝트의 Assets/...에 복사한다.
3. 신규 검증 파일 두 개(Assets/1. Scripts/Editor/Verification/R1AbilityTimingVerification20261030.cs 및 .meta)를 제거한다.
4. Unity AssetDatabase Refresh → Compile; 기존 G0 Golden / Damage G1를 재실행한다.
5. 씬은 저장/되돌리기 대상이 아니다. GitHub 커밋/푸시는 실행하지 않는다.
ORIGINALS는 R1 적용 직전에 백업된 Stage A / Stage B 파일을 조합한 것이고, 동시 진행한 사용자 수정이 있었다면 무조건 덮어쓰지 말고 직접 diff로 병합한다.
