# R8 설치·롤백/사용법
현재 Unity MCP로 이미 적용됨. 동일 프로젝트에 ZIP 중복 설치 금지.

1. Unity 메뉴 Project Abyss > R8 > Native SO Converter + Validator 실행.
2. Dry Run / Refresh → 검증 이슈 확인 → Source SkillDefinition 선택 → 원본 GUID/효과/레벨 미리보기 확인.
3. ReadyToCreate이면 'Stage NEW Native SO' 클릭 후 명시적 확인. 스테이징 SO는 Resources 외부, 즉시 게임 실행 안 됨.
4. 네이티브 실제 동작을 R7/R9 동등성 검증으로 입증한 뒤 운영 Resource 경로로 별도 승격.

롤백: Assets/1. Scripts/Editor/R8 폴더 내 신규 C# 5개 및 해당 .meta와 R8.meta 제거. Unity Refresh/컴파일. 기존 런타임 스크립트와 원본 SO는 변경하지 않았기 때문에 추가 원복 불필요. 씬 저장 및 Git 커밋 금지.
