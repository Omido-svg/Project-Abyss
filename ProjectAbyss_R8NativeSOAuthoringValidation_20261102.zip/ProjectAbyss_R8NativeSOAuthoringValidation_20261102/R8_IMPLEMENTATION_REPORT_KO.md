# Project Abyss R8 SO 저작·검증 — 2026-11-02

## 실제 구현
- 신규 Editor C# 5개 및 .meta: R8NativeAuthoringCore, R8NativeValidation, R8NativeAuthoringWindow, R8NativeDefinitionInspectors, R8NativeAuthoringVerification.
- Unity 메뉴: Project Abyss > R8 > Native SO Converter + Validator.
- 범용 변환기: 단일 리소스, 단일 출혈, 올라프/유진 게이지의 SkillDefinition → 네이티브 SO 스테이징 생성. GUID/StableId/원본 이름/트리거/레벨별 수치 검증, 원본 .asset/.meta SHA-256 백업, 중복 ID·GUID·덮어쓰기·지원하지 않는 조건·굴림·업그레이드 차단.
- **신규 SO는 Resources 밖 Assets/2. Data/R8_Staging에 생성**하여 R7 production catalog로 자동 로딩하지 않음. 후속 R7/R9 동등성 검증 후 별도 승격 필요.
- Inspector: 기존 5종 네이티브 SO(Resource, Status, Mixed, UniqueGauge, Preparation)의 GUID/ID/name/Schema 유효성 및 원본 링크 표시. 식별자/SchemaVersion 편집 잠금, 일반 저작 필드 편집 가능.
- Validator: 스킬 145, 네이티브 SO 37, 증강 63, 아이템 60 전체 읽기 전용 검사. 기존 운영 네이티브 SO 37/37 검증, 손상 0. R7 미완료를 자동 PASS 처리하지 않음.

## 검증
- R8 통합 변환 18/18 PASS: 실제 원본 복제 3종을 SO로 스테이징 생성, 원본 GUID/수치/SHA 검증, 위조·재시도·기존 SO 덮어쓰기 거부, 테스트 SO/폴더 완전 삭제.
- 실제 Inspector 바인딩 5/5 PASS.
- 기존 R8 SkillValidator 10/10, Pilot Backup 12/12, Effectful Backup 10/10 PASS.
- R7 Native Data Gate 11/11, Mixed V2 7/7, UniqueGauge Data 8/8, Preparation Data 8/8 PASS.
- R6 실제 전투 중간 삽입 10/10 PASS, R7 게이지 52/52 PASS.
- G0 원본 에셋+meta 398건 SHA-256 변경 0, 누락 0. Scene Battle Test Scene Dirty/미저장, Unity EditMode, Git 커밋/푸시 없음.

## 미완료/명시적 차단
- R8의 자동 신규 변환은 위 3개 단일 효과 계열만 지원. 복합 피해·상태 및 Preparation은 Inspector/Validator 검증만, 별도 수작업·R7 패리티 필수. 모든 캐릭터 특수/패시브 변환기까지 구현 완료한 것은 아님.
- R8 Validator 결과: blocker 9건(중복 SkillId 4종 8에셋 + 정본 수치 미정 감정 증강 1), warning 60건(모든 아이템 TempBalanceRunItem).
- 기존 R8 SkillValidator의 blockers 8, warnings 85는 감사 범위가 다른 지표임.
- R8 스테이징→운영 SO 자동 승격 미지원: 승인·동등성 검증 후 수동/추후 도구화.
- 기존 백업: ProjectAbyss_R8_PilotBackups_20261030 (18개 원본 파일), ProjectAbyss_R8_EffectfulBackups_20261030 (136개 원본 파일). 이번 ZIP에는 매니페스트만 포함, 실제 원본 복사본은 기존 로컬 폴더에 유지.
